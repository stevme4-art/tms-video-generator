package com.tms.video

import android.os.Bundle
import android.content.Context
import android.os.Environment
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.media.MediaRecorder
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.net.Uri
import android.provider.MediaStore
import android.view.Surface
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.saveable.rememberSaveable
import android.graphics.BitmapFactory
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private data class Scene(val number: Int, val title: String, val description: String, val imageUri: String? = null)

private const val PREFS = "tms_video_generator"
private const val PROJECT_KEY = "project"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TmsVideoGeneratorApp(applicationContext) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TmsVideoGeneratorApp(context: Context) {
    var prompt by remember { mutableStateOf("") }
    var duration by remember { mutableStateOf(5) }
    var scenes by remember { mutableStateOf(listOf<Scene>()) }
    var imageSceneIndex by rememberSaveable { mutableStateOf(-1) }
    val imagePicker = androidx.activity.compose.rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null && imageSceneIndex >= 0) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            scenes = scenes.mapIndexed { index, scene -> if (index == imageSceneIndex) scene.copy(imageUri = uri.toString()) else scene }
        }
        imageSceneIndex = -1
    }
    var status by remember { mutableStateOf("Ready") }
    var busy by remember { mutableStateOf(false) }
    var renderPrepared by remember { mutableStateOf(false) }
    var renderStatus by remember { mutableStateOf("") }
    var renderProgress by remember { mutableStateOf(0f) }
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var narrationUri by remember { mutableStateOf<Uri?>(null) }
    var narrationStatus by remember { mutableStateOf("") }
    var narrationBusy by remember { mutableStateOf(false) }
    var editSceneIndex by rememberSaveable { mutableStateOf(-1) }
    var previewSceneIndex by rememberSaveable { mutableStateOf(-1) }
    var editTitle by rememberSaveable { mutableStateOf("") }
    var editDescription by rememberSaveable { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        val saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(PROJECT_KEY, null)
        if (saved != null) {
            runCatching {
                val obj = JSONObject(saved)
                prompt = obj.optString("prompt")
                duration = obj.optInt("duration", 5).coerceIn(1, 15)
                val arr = obj.optJSONArray("scenes") ?: JSONArray()
                scenes = (0 until arr.length()).map { i ->
                    val item = arr.getJSONObject(i)
                    Scene(item.getInt("number"), item.getString("title"), item.getString("description"), item.optString("imageUri").takeIf { it.isNotBlank() })
                }
                status = if (scenes.isNotEmpty()) "Saved project restored: ${scenes.size} scenes." else "Ready"
            }
        }
    }

    MaterialTheme {
        Scaffold(topBar = {
            TopAppBar(title = { Text("TMS Video Generator") })
        }) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("Create a video", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text("Describe your story, choose a length, then build the scene plan.")
                }
                item {
                    OutlinedTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp),
                        label = { Text("Video idea") },
                        placeholder = { Text("Example: A 5-minute inspirational story about never giving up") }
                    )
                }
                item {
                    Text("Length: ${duration} minute${if (duration == 1) "" else "s"}")
                    Slider(
                        value = duration.toFloat(),
                        onValueChange = { duration = it.toInt().coerceIn(1, 15) },
                        valueRange = 1f..15f,
                        steps = 13
                    )
                    Text("Choose 1–15 minutes for this build.", style = MaterialTheme.typography.bodySmall)
                }
                item {
                    Button(
                        enabled = prompt.isNotBlank() && !busy,
                        onClick = {
                            busy = true
                            status = "Building scene plan..."
                            val count = (duration * 2).coerceIn(2, 30)
                            scenes = (1..count).map { i ->
                                Scene(i, "Scene $i", "Scene ${i}: ${prompt.trim()}")
                            }
                            status = "Scene plan ready: $count scenes."
                            busy = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (busy) "Building..." else "Build Scene Plan") }
                }
                item { Text(status, style = MaterialTheme.typography.bodyMedium) }
                if (scenes.isNotEmpty()) {
                    item {
                        HorizontalDivider()
                        Text("Scenes", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    }
                    itemsIndexed(scenes) { _, scene ->
                        ElevatedCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Text(scene.title, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(4.dp))
                                Text(scene.description)
                                Spacer(Modifier.height(8.dp))
                                OutlinedButton(onClick = {
                                    imageSceneIndex = scene.number - 1
                                    imagePicker.launch(arrayOf("image/*"))
                                }) {
                                    Text(if (scene.imageUri == null) "Add Scene Image" else "Change Scene Image")
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = {
                                        editSceneIndex = scene.number - 1
                                        editTitle = scene.title
                                        editDescription = scene.description
                                    }) { Text("Edit") }
                                    OutlinedButton(onClick = { previewSceneIndex = scene.number - 1 }) { Text("Preview") }
                                    OutlinedButton(onClick = {
                                        scenes = scenes.filterIndexed { index, _ -> index != scene.number - 1 }
                                            .mapIndexed { index, item -> item.copy(number = index + 1) }
                                        status = "Scene removed. ${scenes.size} scenes remain."
                                        videoUri = null
                                        renderPrepared = false
                                    }) { Text("Delete") }
                                    if (scene.imageUri != null) {
                                        OutlinedButton(onClick = {
                                            scenes = scenes.mapIndexed { index, item ->
                                                if (index == scene.number - 1) item.copy(imageUri = null) else item
                                            }
                                        }) { Text("Remove Image") }
                                    }
                                }
                                if (scene.imageUri != null) {
                                    Spacer(Modifier.height(4.dp))
                                    Text("Image attached", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                    item {
                        OutlinedButton(
                            enabled = scenes.size < 30,
                            onClick = {
                                val nextNumber = scenes.size + 1
                                scenes = scenes + Scene(
                                    nextNumber,
                                    "Scene $nextNumber",
                                    "Add a description for scene $nextNumber"
                                )
                                status = "Scene $nextNumber added."
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (scenes.size < 30) "Add Scene" else "Maximum 30 Scenes") }
                    }
                    item {
                        OutlinedButton(
                            onClick = {
                                val obj = JSONObject().apply {
                                    put("prompt", prompt.trim())
                                    put("duration", duration)
                                    put("scenes", JSONArray().apply {
                                        scenes.forEach { scene -> put(JSONObject().apply {
                                            put("number", scene.number)
                                            put("title", scene.title)
                                            put("description", scene.description)
                                            scene.imageUri?.let { put("imageUri", it) }
                                        }) }
                                    })
                                }
                                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                                    .edit().putString(PROJECT_KEY, obj.toString()).apply()
                                status = "Project saved on this device."
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Save Project") }
                    }
                    item {
                        Button(
                            enabled = !busy && scenes.isNotEmpty(),
                            onClick = {
                                busy = true
                                renderPrepared = false
                                renderProgress = 0f
                                videoUri = null
                                renderStatus = "Preparing local video renderer..."
                                val manifest = JSONObject().apply {
                                    put("durationMinutes", duration)
                                    put("sceneCount", scenes.size)
                                    put("scenes", JSONArray().apply {
                                        scenes.forEach { scene -> put(JSONObject().apply {
                                            put("number", scene.number)
                                            put("title", scene.title)
                                            put("description", scene.description)
                                            scene.imageUri?.let { put("imageUri", it) }
                                        }) }
                                    })
                                }
                                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                                    .edit().putString("render_manifest", manifest.toString()).apply()
                                renderPrepared = true
                                scope.launch {
                                    runCatching {
                                        renderVideoLocally(context, scenes, duration) { progress, message ->
                                            renderProgress = progress
                                            renderStatus = message
                                        }
                                    }.onSuccess { uri ->
                                        videoUri = uri
                                        renderProgress = 1f
                                        renderStatus = "Video draft ready. Saved to your device."
                                    }.onFailure { error ->
                                        renderStatus = "Render failed: ${error.message ?: "Unknown error"}"
                                    }
                                    busy = false
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (busy) "Rendering Video..." else "Render Video") }
                        if (renderStatus.isNotBlank()) {
                            Spacer(Modifier.height(8.dp))
                            Text(renderStatus, style = MaterialTheme.typography.bodySmall)
                        }
                        if (renderPrepared) {
                            Spacer(Modifier.height(8.dp))
                            LinearProgressIndicator(progress = { renderProgress }, modifier = Modifier.fillMaxWidth())
                            Spacer(Modifier.height(4.dp))
                            Text("${(renderProgress * 100).toInt()}%", style = MaterialTheme.typography.labelSmall)
                        }
                        if (videoUri != null) {
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = { shareVideo(context, videoUri!!) },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Share Video") }
                        }
                    }
                    item {
                        HorizontalDivider()
                        Text("Narration", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text("Create a voice narration from your scene text using the phone's built-in text-to-speech engine.")
                        Spacer(Modifier.height(8.dp))
                        Button(
                            enabled = scenes.isNotEmpty() && !narrationBusy,
                            onClick = {
                                narrationBusy = true
                                narrationUri = null
                                narrationStatus = "Preparing narration..."
                                val text = scenes.joinToString("\n\n") { scene ->
                                    "Scene ${scene.number}. ${scene.title}. ${scene.description}"
                                }
                                generateNarration(context, text, scope,
                                    onStatus = { message -> narrationStatus = message },
                                    onComplete = { uri ->
                                        narrationUri = uri
                                        narrationBusy = false
                                        narrationStatus = "Narration audio ready on your device."
                                    },
                                    onError = { message ->
                                        narrationBusy = false
                                        narrationStatus = message
                                    })
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (narrationBusy) "Generating Narration..." else "Generate Narration") }
                        if (narrationStatus.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text(narrationStatus, style = MaterialTheme.typography.bodySmall)
                        }
                        if (narrationUri != null) {
                            Spacer(Modifier.height(6.dp))
                            OutlinedButton(
                                onClick = { shareAudio(context, narrationUri!!) },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Share Narration Audio") }
                        }
                    }
                }
                item {
                    Text(
                        "Stage 28 • Scene management + narration audio + slideshow video renderer",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
                if (editSceneIndex >= 0) {
                    item {
                        AlertDialog(
                            onDismissRequest = { editSceneIndex = -1 },
                            title = { Text("Edit Scene ${editSceneIndex + 1}") },
                            text = {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    OutlinedTextField(value = editTitle, onValueChange = { editTitle = it }, label = { Text("Title") })
                                    OutlinedTextField(value = editDescription, onValueChange = { editDescription = it }, label = { Text("Description") }, minLines = 4)
                                }
                            },
                            confirmButton = {
                                Button(onClick = {
                                    scenes = scenes.mapIndexed { index, item ->
                                        if (index == editSceneIndex) item.copy(title = editTitle.trim().ifBlank { "Scene ${index + 1}" }, description = editDescription.trim()) else item
                                    }
                                    val savedSceneNumber = editSceneIndex + 1
                                    editSceneIndex = -1
                                    status = "Scene $savedSceneNumber updated."
                                }) { Text("Save") }
                            },
                            dismissButton = { OutlinedButton(onClick = { editSceneIndex = -1 }) { Text("Cancel") } }
                        )
                    }
                }
                if (previewSceneIndex >= 0 && previewSceneIndex < scenes.size) {
                    val preview = scenes[previewSceneIndex]
                    item {
                        AlertDialog(
                            onDismissRequest = { previewSceneIndex = -1 },
                            title = { Text(preview.title) },
                            text = { Text(preview.description) },
                            confirmButton = { Button(onClick = { previewSceneIndex = -1 }) { Text("Close") } }
                        )
                    }
                }
            }
        }
    }
}

private suspend fun renderVideoLocally(
    context: Context,
    scenes: List<Scene>,
    durationMinutes: Int,
    onProgress: (Float, String) -> Unit
): Uri = withContext(Dispatchers.Default) {
    require(scenes.isNotEmpty()) { "No scenes to render" }

    val output = createVideoOutput(context)
    val recorder = MediaRecorder()
    var surface: Surface? = null
    try {
        recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE)
        recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
        recorder.setVideoSize(1280, 720)
        recorder.setVideoFrameRate(10)
        recorder.setVideoEncodingBitRate(2_500_000)
        recorder.setOutputFile(output.filePath)
        recorder.prepare()
        surface = recorder.surface
        recorder.start()

        val totalSeconds = durationMinutes * 60L
        val sceneSeconds = totalSeconds.toDouble() / scenes.size.toDouble()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val start = System.currentTimeMillis()
        var elapsedSeconds = 0.0
        var lastReported = -1

        while (elapsedSeconds < totalSeconds) {
            val sceneIndex = (elapsedSeconds / sceneSeconds).toInt().coerceIn(0, scenes.lastIndex)
            val scene = scenes[sceneIndex]
            val canvas = surface.lockCanvas()
            try {
                drawScene(context, canvas, scene, sceneIndex + 1, scenes.size, paint)
            } finally {
                surface.unlockCanvasAndPost(canvas)
            }

            elapsedSeconds = (System.currentTimeMillis() - start) / 1000.0
            val percent = ((elapsedSeconds / totalSeconds) * 100).toInt().coerceIn(0, 100)
            if (percent != lastReported) {
                lastReported = percent
                onProgress(percent / 100f, "Rendering scene ${sceneIndex + 1} of ${scenes.size}...")
            }
            Thread.sleep(100L)
        }
        onProgress(1f, "Finalizing video file...")
        recorder.stop()
        recorder.reset()
        output.publish(context)
        output.uri
    } catch (e: Exception) {
        runCatching { recorder.stop() }
        output.cleanup()
        throw e
    } finally {
        runCatching { recorder.release() }
        surface?.release()
    }
}

private data class VideoOutput(
    val uri: Uri,
    val filePath: String,
    val publish: (Context) -> Unit,
    val cleanup: () -> Unit
)

private fun createVideoOutput(context: Context): VideoOutput {
    val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    val name = "TMS_Video_$stamp.mp4"

    if (android.os.Build.VERSION.SDK_INT >= 29) {
        val values = android.content.ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/TMS Video Generator")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val uri = requireNotNull(resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values))
        val temp = File(context.cacheDir, name)
        return VideoOutput(
            uri = uri,
            filePath = temp.absolutePath,
            publish = { ctx ->
                val source = temp
                require(source.exists()) { "Rendered video file was not created" }
                ctx.contentResolver.openOutputStream(uri, "w")!!.use { out ->
                    source.inputStream().use { input -> input.copyTo(out) }
                }
                ctx.contentResolver.update(
                    uri,
                    android.content.ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) },
                    null,
                    null
                )
                source.delete()
            },
            cleanup = {
                runCatching { temp.delete() }
                runCatching { resolver.delete(uri, null, null) }
            }
        )
    }

    val dir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir
    dir.mkdirs()
    val file = File(dir, name)
    val authority = context.packageName + ".fileprovider"
    val uri = FileProvider.getUriForFile(context, authority, file)
    return VideoOutput(
        uri = uri,
        filePath = file.absolutePath,
        publish = { _ -> },
        cleanup = { runCatching { file.delete() } }
    )
}

private fun drawScene(context: Context, canvas: Canvas, scene: Scene, number: Int, total: Int, paint: Paint) {
    canvas.drawColor(android.graphics.Color.rgb(18, 20, 28))
    scene.imageUri?.let { raw ->
        runCatching {
            context.contentResolver.openInputStream(Uri.parse(raw)).use { input ->
                val bitmap = BitmapFactory.decodeStream(input)
                if (bitmap != null) {
                    val src = android.graphics.Rect(0, 0, bitmap.width, bitmap.height)
                    val dst = android.graphics.Rect(0, 0, canvas.width, 720)
                    canvas.drawBitmap(bitmap, src, dst, paint)
                }
            }
        }
    }
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    paint.textSize = 48f
    paint.setColor(android.graphics.Color.WHITE)
    canvas.drawText("TMS VIDEO GENERATOR", 60f, 75f, paint)

    paint.textSize = 34f
    canvas.drawText("Scene $number / $total", 60f, 135f, paint)

    paint.textSize = 58f
    drawWrappedText(canvas, scene.title, 60f, 250f, 1160f, paint, 2)

    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
    paint.textSize = 30f
    drawWrappedText(canvas, scene.description, 60f, 400f, 1160f, paint, 7)

    paint.textSize = 22f
    canvas.drawText("Offline draft render • Add AI media in the next stage", 60f, 670f, paint)
}

private fun drawWrappedText(
    canvas: Canvas,
    text: String,
    x: Float,
    startY: Float,
    maxWidth: Float,
    paint: Paint,
    maxLines: Int
) {
    val words = text.trim().ifBlank { "Untitled" }.split(Regex("\\s+"))
    var line = ""
    var y = startY
    var lines = 0
    for (word in words) {
        val candidate = if (line.isEmpty()) word else "$line $word"
        if (paint.measureText(candidate) > maxWidth && line.isNotEmpty()) {
            canvas.drawText(line, x, y, paint)
            lines++
            if (lines >= maxLines) return
            y += paint.textSize * 1.35f
            line = word
        } else {
            line = candidate
        }
    }
    if (line.isNotEmpty() && lines < maxLines) canvas.drawText(line, x, y, paint)
}

private fun generateNarration(
    context: Context,
    text: String,
    scope: kotlinx.coroutines.CoroutineScope,
    onStatus: (String) -> Unit,
    onComplete: (Uri) -> Unit,
    onError: (String) -> Unit
) {
    val output = File(context.cacheDir, "TMS_Narration_${System.currentTimeMillis()}.wav")
    val tts = TextToSpeech(context) { result ->
        if (result != TextToSpeech.SUCCESS) {
            scope.launch(Dispatchers.Main) { onError("Text-to-speech is not available on this device.") }
            return@TextToSpeech
        }
        tts.language = Locale.getDefault()
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                scope.launch(Dispatchers.Main) { onStatus("Generating narration audio...") }
            }
            override fun onDone(utteranceId: String?) {
                scope.launch(Dispatchers.Main) {
                    tts.shutdown()
                    if (output.exists() && output.length() > 0) {
                        onComplete(FileProvider.getUriForFile(context, context.packageName + ".fileprovider", output))
                    } else {
                        onError("Narration file was not created.")
                    }
                }
            }
            override fun onError(utteranceId: String?) {
                scope.launch(Dispatchers.Main) {
                    tts.shutdown()
                    runCatching { output.delete() }
                    onError("Narration generation failed.")
                }
            }
        })
        val params = android.os.Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "tms_narration")
        }
        val started = tts.synthesizeToFile(text, params, output, "tms_narration")
        if (started != TextToSpeech.SUCCESS) {
            scope.launch(Dispatchers.Main) {
                tts.shutdown()
                runCatching { output.delete() }
                onError("The phone could not start narration generation.")
            }
        }
    }
}

private fun shareAudio(context: Context, uri: Uri) {
    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = "audio/wav"
        putExtra(android.content.Intent.EXTRA_STREAM, uri)
        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(android.content.Intent.createChooser(intent, "Share narration audio"))
}

private fun shareVideo(context: Context, uri: Uri) {
    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = "video/mp4"
        putExtra(android.content.Intent.EXTRA_STREAM, uri)
        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(android.content.Intent.createChooser(intent, "Share TMS video"))
}
