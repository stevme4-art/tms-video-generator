# TMS Video Generator — Stage 28

Stage 28 builds on the corrected Stage 27 project.

## Added
- Scene management and editing
- Local MP4 slideshow rendering
- Built-in phone Text-to-Speech narration generation
- Share narration audio and rendered video
- Project save/restore

The narration feature creates a WAV audio file from the scene text. It is not yet automatically mixed into the MP4; that is a later integration step.
