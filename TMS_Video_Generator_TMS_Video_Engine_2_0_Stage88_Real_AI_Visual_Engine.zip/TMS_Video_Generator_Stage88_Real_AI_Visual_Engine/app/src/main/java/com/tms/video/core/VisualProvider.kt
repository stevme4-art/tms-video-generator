package com.tms.video.core

interface VisualProvider {
    val id: String
    suspend fun generate(scene: ScenePlan): Result<String>
}

interface VideoProvider {
    val id: String
    suspend fun generate(scene: ScenePlan): Result<String>
}

class UnconfiguredVisualProvider : VisualProvider {
    override val id: String = "unconfigured"
    override suspend fun generate(scene: ScenePlan): Result<String> = Result.failure(
        IllegalStateException("No image provider is configured.")
    )
}

class UnconfiguredVideoProvider : VideoProvider {
    override val id: String = "unconfigured"
    override suspend fun generate(scene: ScenePlan): Result<String> = Result.failure(
        IllegalStateException("No video provider is configured.")
    )
}
