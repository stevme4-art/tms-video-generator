package com.tms.video.core

/** Provider-neutral media asset returned by any image/video engine. */
data class GeneratedAsset(
    val sceneIndex: Int,
    val localPath: String,
    val kind: AssetKind,
    val providerId: String,
    val durationSeconds: Int? = null
)

enum class AssetKind { IMAGE, VIDEO }

/** A future timeline can consume assets without knowing which AI provider made them. */
data class TimelineClip(
    val sceneIndex: Int,
    val asset: GeneratedAsset,
    val startSeconds: Int,
    val durationSeconds: Int
)
