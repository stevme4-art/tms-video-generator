package com.tms.video.core

class ProductionEngine(private val visualProvider: VisualProvider = UnconfiguredVisualProvider()) {
    fun createPlan(request: VideoRequest, customSceneCount: Int = 0): ProductionPlan = TmsDirector.plan(request, customSceneCount)
    fun providerName(): String = visualProvider.id
}
