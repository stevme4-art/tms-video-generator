package com.tms.video.core

object TmsDirector {
    fun plan(request: VideoRequest, customSceneCount: Int = 0): ProductionPlan {
        val count = if (request.sceneMode == SceneMode.CUSTOM) customSceneCount.coerceIn(2, 60)
        else autoSceneCount(request.durationSeconds)
        val base = request.durationSeconds / count
        val remainder = request.durationSeconds % count
        val character = CharacterProfile("char_01", "Main Character", "Keep face, age, hair, body proportions and defining clothing consistent across every scene.")
        val location = LocationProfile("loc_01", "Primary Location", "Maintain geography, architecture, lighting direction and environmental continuity across scenes.")
        val scenes = (1..count).map { i ->
            val seconds = base + if (i <= remainder) 1 else 0
            val phase = when {
                i == 1 -> "Opening establishing moment"
                i == count -> "Resolution and closing moment"
                i <= count / 3 -> "Setup and rising action"
                i <= (count * 2) / 3 -> "Development and turning point"
                else -> "Climax and resolution"
            }
            ScenePlan(i, "${phase.replaceFirstChar { it.uppercase() }} — Scene $i",
                "Develop scene $i from the user's story idea while preserving continuity. $phase.",
                buildVisualPrompt(request, i, count, character, location), seconds,
                listOf(character.id), listOf(location.id), shotFor(i, count), if (i == 1) "Fade" else "Cut")
        }
        return ProductionPlan(request, scenes, listOf(character), listOf(location))
    }

    private fun autoSceneCount(seconds: Int): Int = when {
        seconds <= 30 -> 4
        seconds <= 60 -> 6
        seconds <= 180 -> 12
        seconds <= 300 -> 20
        seconds <= 600 -> 30
        else -> (seconds / 15).coerceIn(8, 60)
    }

    private fun shotFor(i: Int, total: Int): String = when {
        i == 1 -> "Wide establishing shot"
        i == total -> "Close-up resolution shot"
        i % 5 == 0 -> "Tracking shot"
        i % 3 == 0 -> "Close-up"
        else -> "Medium cinematic shot"
    }

    private fun buildVisualPrompt(r: VideoRequest, i: Int, total: Int, c: CharacterProfile, l: LocationProfile): String =
        "Production-quality ${r.style.lowercase()} ${r.aspectRatio} scene for scene $i of $total. " +
        "Story idea: ${r.idea.trim()}. Preserve ${c.identity} ${l.identity}. " +
        "Use natural lighting, believable anatomy, coherent perspective, cinematic composition, detailed environment, " +
        "appropriate depth of field and a clear subject. Do not add text, captions, logos or watermarks."
}
