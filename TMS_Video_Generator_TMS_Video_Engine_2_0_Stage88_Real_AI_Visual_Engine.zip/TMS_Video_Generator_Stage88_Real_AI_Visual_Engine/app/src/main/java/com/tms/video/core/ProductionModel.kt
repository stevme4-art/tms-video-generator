package com.tms.video.core

data class VideoRequest(
    val idea: String,
    val durationSeconds: Int,
    val style: String,
    val aspectRatio: String,
    val sceneMode: SceneMode
)

enum class SceneMode { AUTO, CUSTOM }

data class CharacterProfile(val id: String, val name: String, val identity: String)
data class LocationProfile(val id: String, val name: String, val identity: String)
data class ScenePlan(
    val index: Int,
    val title: String,
    val description: String,
    val visualPrompt: String,
    val durationSeconds: Int,
    val characters: List<String> = emptyList(),
    val locations: List<String> = emptyList(),
    val shot: String = "Medium shot",
    val transition: String = "Cut"
)
data class ProductionPlan(
    val request: VideoRequest,
    val scenes: List<ScenePlan>,
    val characters: List<CharacterProfile>,
    val locations: List<LocationProfile>
)
