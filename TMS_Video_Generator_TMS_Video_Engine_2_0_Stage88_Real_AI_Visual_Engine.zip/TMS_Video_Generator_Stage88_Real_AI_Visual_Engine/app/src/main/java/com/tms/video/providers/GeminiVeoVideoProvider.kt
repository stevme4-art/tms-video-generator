package com.tms.video.providers

import android.content.Context
import com.tms.video.core.ScenePlan
import com.tms.video.core.VideoProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Real Gemini/Veo video adapter. Veo generation is asynchronous and polled. */
class GeminiVeoVideoProvider(
    private val context: Context,
    private val apiKey: String,
    private val model: String = "veo-3.1-generate-preview"
) : VideoProvider {
    override val id: String = "gemini-veo:$model"

    override suspend fun generate(scene: ScenePlan): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            require(apiKey.isNotBlank()) { "Enter a Gemini API key first." }
            val base = "https://generativelanguage.googleapis.com/v1beta"
            val request = JSONObject().apply {
                put("instances", org.json.JSONArray().put(JSONObject().apply {
                    put("prompt", scene.visualPrompt + " Motion: natural cinematic movement. Keep the subject and environment coherent throughout the shot.")
                }))
                put("parameters", JSONObject().apply {
                    put("aspectRatio", if (scene.visualPrompt.contains("9:16")) "9:16" else "16:9")
                    put("negativePrompt", "low quality, distorted anatomy, extra limbs, flicker, text, logo, watermark")
                })
            }
            val operation = postJson("$base/models/$model:predictLongRunning", request.toString(), apiKey)
            val operationName = JSONObject(operation).optString("name")
            require(operationName.isNotBlank()) { "Veo did not return an operation name: ${operation.take(800)}" }

            var status = JSONObject()
            var attempts = 0
            while (!status.optBoolean("done", false) && attempts < 60) {
                delay(10_000)
                val raw = getJson("$base/$operationName", apiKey)
                status = JSONObject(raw)
                attempts++
            }
            require(status.optBoolean("done", false)) { "Video generation timed out while waiting for Veo." }
            val uri = status.optJSONObject("response")
                ?.optJSONObject("generateVideoResponse")
                ?.optJSONArray("generatedSamples")
                ?.optJSONObject(0)
                ?.optJSONObject("video")
                ?.optString("uri").orEmpty()
            require(uri.isNotBlank()) { "Veo completed without a downloadable video URI." }

            val dir = File(context.filesDir, "tms/generated/videos").apply { mkdirs() }
            val file = File(dir, "scene_${scene.index}_${System.currentTimeMillis()}.mp4")
            download(uri, apiKey, file)
            file.absolutePath
        }
    }

    private fun postJson(url: String, body: String, apiKey: String): String {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 30_000
            readTimeout = 120_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", apiKey)
        }
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        return readResponse(connection, "Veo request")
    }

    private fun getJson(url: String, apiKey: String): String {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 30_000
            readTimeout = 60_000
            setRequestProperty("x-goog-api-key", apiKey)
        }
        return readResponse(connection, "Veo status request")
    }

    private fun readResponse(connection: HttpURLConnection, operation: String): String {
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code !in 200..299) error("$operation failed ($code): ${text.take(1200)}")
        return text
    }

    private fun download(uri: String, apiKey: String, target: File) {
        val connection = (URL(uri).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 30_000
            readTimeout = 180_000
            setRequestProperty("x-goog-api-key", apiKey)
        }
        val code = connection.responseCode
        require(code in 200..299) { "Video download failed ($code)." }
        connection.inputStream.use { input -> FileOutputStream(target).use { output -> input.copyTo(output) } }
    }
}
