package com.tms.video.providers

import android.content.Context
import com.tms.video.core.ScenePlan
import com.tms.video.core.VisualProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import android.util.Base64

/**
 * Real Gemini native image generation adapter.
 * Core TMS remains provider-independent; this class is only an adapter.
 */
class GeminiImageProvider(
    private val context: Context,
    private val apiKey: String,
    private val model: String = "gemini-3.1-flash-image"
) : VisualProvider {
    override val id: String = "gemini-image:$model"

    override suspend fun generate(scene: ScenePlan): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            require(apiKey.isNotBlank()) { "Enter a Gemini API key first." }
            val endpoint = "https://generativelanguage.googleapis.com/v1beta/interactions"
            val body = JSONObject().apply {
                put("model", model)
                put("input", org.json.JSONArray().put(JSONObject().apply {
                    put("type", "text")
                    put("text", scene.visualPrompt)
                }))
                put("response_format", JSONObject().apply {
                    put("type", "image")
                    put("mime_type", "image/png")
                    put("aspect_ratio", normalizeAspectRatio(scene.visualPrompt))
                    put("image_size", "2K")
                })
            }
            val response = postJson(endpoint, body.toString(), apiKey)
            val json = JSONObject(response)
            val data = json.optJSONObject("output_image")?.optString("data").orEmpty()
            require(data.isNotBlank()) { "Gemini returned no image. Response: ${response.take(800)}" }
            val bytes = Base64.decode(data, Base64.DEFAULT)
            val dir = File(context.filesDir, "tms/generated/images").apply { mkdirs() }
            val file = File(dir, "scene_${scene.index}_${System.currentTimeMillis()}.png")
            file.writeBytes(bytes)
            file.absolutePath
        }
    }

    private fun normalizeAspectRatio(prompt: String): String = when {
        prompt.contains("9:16") -> "9:16"
        prompt.contains("1:1") -> "1:1"
        prompt.contains("4:3") -> "4:3"
        else -> "16:9"
    }

    private fun postJson(url: String, body: String, apiKey: String): String {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 30_000
            readTimeout = 120_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", apiKey)
        }
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code !in 200..299) error("Gemini image request failed ($code): ${text.take(1200)}")
        return text
    }
}
