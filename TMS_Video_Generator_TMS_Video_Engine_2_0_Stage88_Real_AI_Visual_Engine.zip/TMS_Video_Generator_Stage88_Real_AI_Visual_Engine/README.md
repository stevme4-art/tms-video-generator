# TMS Video Generator — Stage 88 — Real AI Visual Generation

Stage 88 keeps the clean Stage 87 engine core and adds real provider adapters.

## Real generators
- **Images:** Gemini 3.1 Flash Image (`gemini-3.1-flash-image`, Nano Banana 2)
- **Video:** Veo 3.1 (`veo-3.1-generate-preview`)

Google's current Gemini documentation identifies Nano Banana 2 as `gemini-3.1-flash-image` and Veo 3.1 as `veo-3.1-generate-preview`. Image generation is synchronous through the Interactions API; Veo uses a long-running operation that TMS polls until the video is ready.

## TMS architecture rule
Gemini is **not** the TMS engine. It is a provider adapter behind `VisualProvider` and `VideoProvider`. Another provider can be added without rewriting the Director, scene planner, character memory, world memory or timeline contracts.

## Stage 88 capabilities
- Real AI scene-image generation
- 2K image output request
- 16:9 / 9:16 scene output
- Real Veo video generation for a scene
- Asynchronous Veo polling and download
- Scene-by-scene generation progress
- Generated image preview in the app
- Provider IDs and error handling
- Dynamic scene counts remain 2–60 for custom mode

## Security note
This prototype accepts a Gemini API key directly on-device so the generation path can be tested. A public release should use a secure backend/token broker rather than embedding a long-lived provider key in an APK.


## Important
Stage 88 is the first stage where TMS actually calls a real image-generation service and a real video-generation service. The old procedural visual engine is not used.
