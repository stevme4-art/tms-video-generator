package com.tms.video.core

interface VisualProvider {
    val id: String
    suspend fun generate(scene: ScenePlan): Result<String>
}

/** Provider boundary only. Real cloud/on-device providers are added in later stages. */
class UnconfiguredVisualProvider : VisualProvider {
    override val id: String = "unconfigured"
    override suspend fun generate(scene: ScenePlan): Result<String> = Result.failure(
        IllegalStateException("No visual provider is configured. The engine is ready for a provider adapter.")
    )
}
