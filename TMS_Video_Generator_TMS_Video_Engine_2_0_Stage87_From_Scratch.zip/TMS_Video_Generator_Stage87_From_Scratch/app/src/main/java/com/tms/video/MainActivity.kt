package com.tms.video

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tms.video.core.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { TmsApp() } }
}

@Composable
fun TmsApp() {
    var idea by remember { mutableStateOf("") }
    var duration by remember { mutableStateOf("60") }
    var style by remember { mutableStateOf("Realistic Cinematic") }
    var ratio by remember { mutableStateOf("16:9") }
    var mode by remember { mutableStateOf(SceneMode.AUTO) }
    var customCount by remember { mutableStateOf("10") }
    var plan by remember { mutableStateOf<ProductionPlan?>(null) }
    var message by remember { mutableStateOf("Ready — TMS Engine 2.0 is initialized from a clean architecture.") }
    val engine = remember { ProductionEngine() }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("TMS Video Generator 2.0") }) }) { pad ->
            LazyColumn(modifier = Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { Text("AI Director", style = MaterialTheme.typography.headlineSmall) }
                item { Text("Describe your video once. TMS will build the production plan underneath.") }
                item { OutlinedTextField(idea, { idea = it }, Modifier.fillMaxWidth(), label = { Text("What do you want to create?") }, minLines = 4) }
                item { OutlinedTextField(duration, { duration = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text("Duration (seconds)") }) }
                item { OutlinedTextField(style, { style = it }, Modifier.fillMaxWidth(), label = { Text("Visual style") }) }
                item { OutlinedTextField(ratio, { ratio = it }, Modifier.fillMaxWidth(), label = { Text("Aspect ratio") }) }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = mode == SceneMode.AUTO, onClick = { mode = SceneMode.AUTO }, label = { Text("Auto scenes") })
                        FilterChip(selected = mode == SceneMode.CUSTOM, onClick = { mode = SceneMode.CUSTOM }, label = { Text("Custom scenes") })
                    }
                }
                if (mode == SceneMode.CUSTOM) item { OutlinedTextField(customCount, { customCount = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text("Number of scenes (2–60)") }) }
                item {
                    Button(enabled = idea.isNotBlank(), onClick = {
                        val request = VideoRequest(idea, duration.toIntOrNull()?.coerceAtLeast(1) ?: 60, style, ratio, mode)
                        plan = engine.createPlan(request, customCount.toIntOrNull() ?: 10)
                        message = "Production plan created: ${plan!!.scenes.size} scenes. Visual provider slot: ${engine.providerName()}."
                    }, modifier = Modifier.fillMaxWidth()) { Text("CREATE PRODUCTION PLAN") }
                }
                item { Text(message, style = MaterialTheme.typography.bodyMedium) }
                plan?.let { p ->
                    item { HorizontalDivider(); Text("Production Plan", style = MaterialTheme.typography.headlineSmall); Text("${p.scenes.size} scenes • ${p.characters.size} character profile • ${p.locations.size} location profile") }
                    item { Text("Character continuity: ${p.characters.first().identity}") }
                    item { Text("World continuity: ${p.locations.first().identity}") }
                    items(p.scenes) { s ->
                        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("Scene ${s.index}: ${s.title}", style = MaterialTheme.typography.titleMedium)
                            Text("${s.durationSeconds}s • ${s.shot} • ${s.transition}")
                            Text(s.description)
                            Text("Visual prompt ready", style = MaterialTheme.typography.labelMedium)
                        }}
                    }
                }
            }
        }
    }
}
