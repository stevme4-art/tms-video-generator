# TMS Video Generator — Stage 87 — From Scratch

This is a clean Engine 2.0 foundation. The video-generation engine is not derived from the Stage 84–86 visual implementation.

## Architecture
- `TmsDirector`: story-to-production planning
- `ProductionModel`: request, scene, character and world contracts
- `ProductionEngine`: orchestration boundary
- `VisualProvider`: provider-independent image generation interface
- `UnconfiguredVisualProvider`: explicit placeholder until a real provider adapter is implemented
- Compose UI: intentionally thin client over the engine

## Stage 87 scope
- Dynamic Auto/Custom scene planning (2–60 custom scenes)
- Duration-aware scene timing
- Character continuity contract
- Location/world continuity contract
- Per-scene cinematic shot direction
- Per-scene production-quality visual prompt
- Provider abstraction so Gemini or another service is an adapter, not the engine itself

## Next stage
Implement the first real visual provider adapter and connect generated assets to a media timeline without rebuilding the core again.
