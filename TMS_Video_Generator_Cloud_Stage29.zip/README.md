# TMS Video Generator — Stage 29

Stage 29 builds on the corrected Stage 28 project.

## Added
- Narration speech-rate control (0.5x–1.5x)
- Narration pitch control (0.5x–1.5x)
- Settings are applied when generating the WAV narration
- Existing scene editing, images, MP4 rendering, project save/restore, and sharing remain

## Current limitation
The local renderer still produces a video draft from scene cards/images. Narration is generated as a separate WAV file and is not automatically mixed into the MP4 yet.
