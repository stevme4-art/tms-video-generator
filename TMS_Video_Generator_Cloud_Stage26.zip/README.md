# TMS AI Video Generator — Stage 26

Stage 26 adds scene image import and renders those images into the offline MP4 draft renderer.

## Features
- 1–15 minute projects
- Scene-plan generation
- Save/restore projects
- Attach an image to each scene using Android document picker
- Persist selected image permissions where supported
- Render an MP4 slideshow using the attached scene images and scene text
- Share the rendered MP4

This remains an offline/local renderer. AI image generation, narration, music, transitions and cloud rendering are future integration stages.
