# TMS Video Generator — Stage 69

Stage 32 builds on the Stage 31 project and adds multi-format video export.

## Added
- Added video format selection: 16:9 landscape, 9:16 portrait, and 1:1 square.
- Export resolution automatically adapts to the selected format (1280×720, 720×1280, or 720×720).
- Scene rendering layout adapts to landscape, portrait, and square canvases.
- Saved projects remember the selected video format.

## Existing Stage 31 features
- Added optional background music from the phone.
- Background music can loop to the video duration.
- Added a background-music volume control.
- Narration and background music can be mixed together into the final MP4.
- Final audio export uses AndroidX Media3 Composition to mix overlapping audio sequences.
- Fixed the Stage 29 narration-generation call so speech-rate and pitch settings are passed correctly.
- Added **Create Video With Narration** to combine the rendered MP4 with the generated narration track.
- Uses AndroidX Media3 Transformer to export a standard MP4 with AAC audio.
- Saves the narrated video to the device's Movies/TMS Video Generator folder on Android 10+.
- Existing scene editing, image attachments, project save/restore, local rendering, narration generation, and sharing remain.

## Current limitation
The app still uses the local slideshow renderer and Android text-to-speech. AI-generated images/video, cloud rendering, and advanced voice generation are not yet connected.

## Stage 33
- Added project naming.
- Added an independent 2–30 scene-count control.
- Saved projects now remember the project name and scene count.
- Added a New Project reset action.
- Preserved Stage 32 duration, aspect-ratio, narration, music, scene editing, preview, and local rendering features.

## Stage 34
- Upgraded Scene Preview to show the attached scene image when available.
- Preview now displays the scene title, image, and description together.
- Kept Stage 33 project naming, 2–30 scene control, New Project, narration, music mixing, multi-format rendering, and local project saving.

## Stage 35
- Added scene ordering controls with Up and Down buttons.
- Reordering automatically renumbers scenes and invalidates the old render so the next render follows the new order.
- Preserved Stage 34 visual scene preview and all previous project, scene, narration, music, and multi-format features.

## Stage 36
- Added one-tap scene duplication.
- Duplicated scenes keep their attached image and description, and are inserted directly after the selected scene.
- Scene numbering is automatically rebuilt after duplication.
- Maximum project size remains 30 scenes.

## Stage 37
- Added image thumbnails directly to scene cards.
- Improved rendered scene images with center-crop framing to avoid stretching.
- Updated renderer branding/footer to Stage 37.
- Preserved all Stage 36 scene management, duplication, preview, project saving, narration, music, and multi-format features.

## Stage 38
- Added an individual duration control for every scene (1–30 seconds).
- The estimated total video length updates from the scene durations.
- Rendering now uses each scene's own duration instead of one duration for every scene.
- Scene duration is saved and restored with projects.

## Stage 39
- Fixed per-scene duration persistence when saving and restoring projects.
- Fixed the local renderer so each scene actually plays for its configured duration.
- Rendering now follows the ordered cumulative scene durations instead of giving every scene equal time.
- The final rendered length is capped by the selected overall length setting.

## Stage 40
- Added Export Backup to save the current project as a portable `.tmsproject.json` file.
- Added Import Backup to restore a project from a backup file.
- Backups preserve project name, prompt, duration, format, scene order, scene images, and per-scene durations.
- Import is limited to 30 scenes and clears the previous rendered-video state.

## Stage 41
- Added per-scene duration controls (1–30 seconds).
- Added Cut, Fade, and Slide transitions between scenes.
- Transition settings are saved/restored in project backups.
- Fade and Slide transitions are applied during local rendering.

## Stage 42
- Added project-level Visual Style presets: Cinematic, Documentary, and Cartoon.
- Visual Style is saved and restored with project backups.
- The selected style is reflected in the local scene renderer.

## Stage 43
- Stability pass for the Stage 42 Visual Style renderer.
- Visual Style is now passed explicitly into scene rendering.
- Backup import now restores each scene's Cut/Fade/Slide transition.
- Locally saved projects restore the selected Cinematic/Documentary/Cartoon style.


## Stage 45
- Added working project-level Visual Style controls: Cinematic, Documentary, and Cartoon.
- Fixed the local renderer to receive the selected Visual Style explicitly.
- Extended scene timing from 1–30 seconds to 1–120 seconds.
- Build Scene Plan now distributes the selected 1–15 minute target across scenes and automatically adds enough scenes when needed to stay within the 120-second scene limit.
- Locally saved projects now restore Visual Style and Cut/Fade/Slide transitions correctly.
- Render manifests now include scene duration and transition metadata.
- Updated Android version to 0.34.0 / versionCode 33.


## Stage 45
- Adds one-tap target-length matching so scene durations can be redistributed to exactly match the selected 1–15 minute target.
- Preserves visual styles, transitions, project backup/import, narration, background music, and local rendering.
- Android version: 0.34.0 (versionCode 34).


## Stage 46
- Added **Optimize Scene Count & Match Target** to automatically add enough scenes for the selected 1–15 minute target while respecting the 120-second maximum per scene.
- Improved target matching feedback when existing scenes cannot reach the requested duration because of the per-scene limit.
- Keeps visual styles, transitions, project backup, narration, music mixing, multi-format rendering, scene editing, preview, and local rendering from earlier stages.
- Android version upgraded to 0.35.0 (version code 35).

## Current limitation
The app still uses the local slideshow renderer and Android text-to-speech. AI-generated images/video, cloud rendering, and advanced voice generation are not yet connected.


## Stage 48

- Added Production Readiness Check for timing, descriptions, scene limits, and attached media.
- Reports whether the project timeline matches the selected target before rendering.
- Android version upgraded to 0.37.0 (version code 37).

## Stage 47
- Added **Enhance Storyboard**, a local storyboard helper that turns the video idea into stronger scene titles and descriptions.
- Uses narrative beats such as Hook, Setup, Challenge, Turning Point, Climax, and Resolution.
- Applies the selected Cinematic, Documentary, or Cartoon visual direction to generated scene descriptions.
- Preserves scene images, durations, transitions, ordering, project backup/import, narration, music, multi-format rendering, and target-length optimization.
- Android version upgraded to 0.36.0 (version code 36).

## Current limitation
The app still uses the local slideshow renderer and Android text-to-speech. AI-generated images/video, cloud rendering, and advanced voice generation are not yet connected.

## Stage 49
- Added **Narration Timing Check** to estimate voice-over duration from scene descriptions using the selected speech rate.
- Flags scenes where estimated narration is longer than the configured scene duration.
- Keeps all storyboard, timing, transitions, backups, media, rendering, and production-readiness features from earlier stages.
- Android version upgraded to 0.38.0 (version code 38).


## Stage 50
- Added **Auto-Fit Narration Timing** to automatically redistribute scene durations based on estimated narration length.
- Respects the 1–120 second per-scene limit and the selected overall target length.
- Keeps manual duration controls, narration timing checks, storyboard tools, transitions, backups, media, multi-format rendering, and production-readiness checks.
- Android version upgraded to 0.39.0 (version code 39).


## Stage 51
- Added **Preview Narration Script** so users can review the complete scene-by-scene narration before generating audio.
- Keeps narration timing checks and auto-fit timing from Stage 49–50.
- Preserves storyboard enhancement, visual styles, transitions, project backup/import, media selection, multi-format rendering, background music, and local text-to-speech.
- Android version upgraded to 0.40.0 (version code 40).


## Stage 52
- Added quick narration voice presets: Calm, Storyteller, Energetic, and Deep.
- Presets tune speech rate and pitch while keeping manual controls available.
- Android version upgraded to 0.41.0 (version code 41).


## Stage 53
- Added **Preview Voice** to let users hear the selected built-in narration voice before generating the full narration.
- The preview uses the current speech-rate, pitch, and voice preset settings.
- Added clear preview status feedback and safe Text-to-Speech cleanup.
- Android version upgraded to 0.42.0 (version code 42).


## Stage 64
- Voice speech rate, pitch, and selected preset are now saved with local projects and portable project backups.
- Imported projects restore the saved narration voice settings with safe defaults for older backups.
- New Project resets narration voice settings to the Storyteller defaults.
- Preserves Stage 53 voice preview, narration script preview, auto-fit timing, storyboard, transitions, backups, background music, multi-format rendering, and local text-to-speech.
- Android version upgraded to 0.43.0 (version code 43).

## Current limitation
The app still uses the local slideshow renderer and Android text-to-speech. AI-generated images/video, cloud rendering, and advanced voice generation are not yet connected.


## Stage 55 upgrade
- Added a custom narration voice-preview text field (up to 500 characters).
- Preview Voice now speaks the text entered by the creator using the selected preset, speech rate, and pitch.
- Existing Stage 54 project save/import behavior remains intact.


## Stage 56
- Added **Stop Voice Preview** so a long custom voice preview can be stopped immediately.
- Preview cleanup now safely releases the active Android Text-to-Speech engine when stopped, finished, or when an error occurs.
- Preserves Stage 55 custom preview text, voice presets, speech rate/pitch controls, narration script preview, auto-fit timing, storyboard tools, transitions, backups, background music, multi-format rendering, and local text-to-speech.
- Android version upgraded to 0.44.0 (version code 43).


## Stage 57
- Added **Clear Preview Text** to quickly remove the current custom voice-preview text.
- Keeps the Stage 56 Stop Voice Preview safety controls and all previous narration, storyboard, timing, backup, music, rendering, and visual-style features.
- Android version upgraded to 0.45.0 (version code 44).


## Stage 58
- Added a **Preview Text Character Counter** showing the current custom voice-preview text length out of 500 characters.
- Added **Restore Default Preview Text** to quickly return to the original sample sentence.
- Preserves Stage 57 Clear Preview Text, Stage 56 Stop Voice Preview, voice presets, saved narration settings, narration script preview, auto-fit timing, storyboard, transitions, backups, music, rendering, and local text-to-speech.
- Android version upgraded to 0.46.0 (version code 45).

## Stage 59
- Added **Voice Preview Duration Estimate** showing word count and approximate preview length from the selected speech rate.
- Helps creators judge whether custom preview text is too short or too long before starting playback.
- Preserves Stage 58 character counter, Restore Default Preview Text, Stage 57 Clear Preview Text, Stop Voice Preview, voice presets, narration script preview, auto-fit timing, storyboard, transitions, backups, music, rendering, and local text-to-speech.
- Android version upgraded to 0.47.0 (version code 46).

## Stage 60 update
- Added quick Short, Standard, and Long voice-preview sample buttons.
- Samples work with the existing speech-rate, pitch, character counter, duration estimate, clear, restore, and stop controls.


## Stage 61 update
- Added a live voice-preview progress indicator.
- Shows elapsed preview time versus the estimated total duration while playback is running.
- Preserves all Stage 60 quick preview samples and earlier narration controls.
- Android version upgraded to 0.48.0 (version code 47).


## Stage 62
- Added a live voice-preview percentage indicator.
- Added an estimated remaining-time display while the voice preview is playing.
- Preserved all Stage 61 voice-preview controls and progress tracking.


## Stage 63
- Save the current voice preview text on the device.
- Restore the saved preview text after reopening the app.
- Keeps all Stage 62 voice preview progress and timing features.


## Stage 64
- Added a Copy Preview Text action for the voice-preview editor.
- Copies the current preview text to the Android clipboard for reuse elsewhere.


## Stage 65
- Added **Paste Preview Text** to load narration preview text directly from the Android clipboard.
- Clipboard text is limited to the existing 500-character preview limit.
- Keeps Copy Preview Text, saved preview text, quick samples, progress tracking, voice presets, narration controls, storyboard tools, backups, music, rendering, and local text-to-speech.
- Android version upgraded to 0.50.0 (version code 49).


## Stage 66
- Added **Share Preview Text** to open the Android share sheet with the current custom narration preview text.
- Keeps Copy Preview Text, Paste Preview Text, saved preview text, quick samples, character counting, duration estimates, voice presets, narration controls, storyboard tools, backups, music, rendering, and local text-to-speech.
- Android version upgraded to 0.51.0 (version code 50).


## Stage 67
- Added **Save Narration Script**.
- Exports the current scene-by-scene narration as a UTF-8 `.txt` file using Android's document picker.
- Uses the project name for the suggested filename.


## Stage 68
- Added **Copy Narration Script** to copy the complete scene-by-scene narration to the phone clipboard.
- Keeps the existing narration preview and Save Narration Script export.


## Stage 69
- Consolidated the Stage 68 narration workflow as the current project baseline.
- Includes narration preview, saving the narration script as a TXT file, sharing preview text, and copying the narration script to the clipboard.
- No changes to the existing video-generation pipeline.


## Stage 70
- Added Share Narration Script so the complete scene-by-scene script can be sent to another app.


## Stage 78 — AI Visual Generation
- Added TMS Visual Engine for scene visuals using the TMS Visual Engine Interactions API and `TMS Visual Engine-3.1-flash-image`.
- Added a TMS Visual Engine API key field and a **Generate Missing AI Visuals** action.
- Generates one image per scene that does not already have an attached image, saves it locally, attaches it to the scene, and keeps the existing local video renderer.
- The app requires Internet permission for image generation.
- For personal testing the API key is stored locally on-device; production releases should use a secure backend/proxy instead of embedding a personal key in the APK.
- Updated Android version to 1.0.78 (version code 78).

## Stage 81 — Create Visuals from Scratch
- Changed the primary scene-image action from **Add Scene Image** to **Create Image from Scratch**.
- The primary action now directly runs the built-in TMS Visual Engine using the scene title/description, visual style, and aspect ratio.
- Manual file selection is still available only as **Use Existing Image (Optional)**, preserving image upload as a fallback rather than the main visual-generation workflow.
- Renamed the project-level action to **Create Missing TMS Visuals** so the wording consistently describes creation rather than adding/importing.
- UI text explicitly tells the engine workflow that TMS creates visuals from scratch and does not depend on Gemini, an API key, or an external AI image service.
- Android version: 1.0.81 (version code 81).


## Stage 82 — Usable Create-Scene Workflow
- Promoted **Create Scene Image** as the exact primary scene-image action label.
- Promoted **Create All Scene Visuals** as the project-level bulk creation action.
- Kept **Use Existing Image (Optional)** as the fallback only.
- Removed stale **Add Scene Image** wording from the active project documentation.
- Removed the stale Stage 44 watermark from rendered video frames.
- Android version: 1.0.82 (version code 82).
