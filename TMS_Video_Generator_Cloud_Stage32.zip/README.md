# TMS Video Generator — Stage 32

Stage 32 builds on the Stage 31 project and adds multi-format video export.

## Added
- Added video format selection: 16:9 landscape, 9:16 portrait, and 1:1 square.
- Export resolution automatically adapts to the selected format (1280×720, 720×1280, or 720×720).
- Scene rendering layout adapts to landscape, portrait, and square canvases.
- Saved projects remember the selected video format.

## Existing Stage 31 features
- Added optional background music from the phone.
- Background music can loop to the video duration.
- Added a background-music volume control.
- Narration and background music can be mixed together into the final MP4.
- Final audio export uses AndroidX Media3 Composition to mix overlapping audio sequences.
- Fixed the Stage 29 narration-generation call so speech-rate and pitch settings are passed correctly.
- Added **Create Video With Narration** to combine the rendered MP4 with the generated narration track.
- Uses AndroidX Media3 Transformer to export a standard MP4 with AAC audio.
- Saves the narrated video to the device's Movies/TMS Video Generator folder on Android 10+.
- Existing scene editing, image attachments, project save/restore, local rendering, narration generation, and sharing remain.

## Current limitation
The app still uses the local slideshow renderer and Android text-to-speech. AI-generated images/video, cloud rendering, and advanced voice generation are not yet connected.
