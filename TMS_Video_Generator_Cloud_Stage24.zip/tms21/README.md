# TMS Video Generator — Stage 24

Stage 24 builds on Stage 23.

## Added
- Offline local MP4 draft renderer using Android's H.264 MediaRecorder.
- Converts the scene plan into a real 1280×720 MP4 video.
- Supports 1–15 minute projects.
- Shows render progress while the video is being created.
- Saves finished videos to the device's Movies/TMS Video Generator folder on modern Android.
- Share Video button for the finished MP4.
- Project persistence and render manifest from Stage 23 are preserved.

## Important
This is a **local draft renderer**: it creates a real video from scene text cards. It does not yet generate AI images, AI animation, or AI voice. The next stage can add media generation and audio to the rendered timeline.
