# TMS Video Generator — Stage 32

Stage 32 builds on the Stage 31 project and adds multi-format video export.

## Added
- Added video format selection: 16:9 landscape, 9:16 portrait, and 1:1 square.
- Export resolution automatically adapts to the selected format (1280×720, 720×1280, or 720×720).
- Scene rendering layout adapts to landscape, portrait, and square canvases.
- Saved projects remember the selected video format.

## Existing Stage 31 features
- Added optional background music from the phone.
- Background music can loop to the video duration.
- Added a background-music volume control.
- Narration and background music can be mixed together into the final MP4.
- Final audio export uses AndroidX Media3 Composition to mix overlapping audio sequences.
- Fixed the Stage 29 narration-generation call so speech-rate and pitch settings are passed correctly.
- Added **Create Video With Narration** to combine the rendered MP4 with the generated narration track.
- Uses AndroidX Media3 Transformer to export a standard MP4 with AAC audio.
- Saves the narrated video to the device's Movies/TMS Video Generator folder on Android 10+.
- Existing scene editing, image attachments, project save/restore, local rendering, narration generation, and sharing remain.

## Current limitation
The app still uses the local slideshow renderer and Android text-to-speech. AI-generated images/video, cloud rendering, and advanced voice generation are not yet connected.

## Stage 33
- Added project naming.
- Added an independent 2–30 scene-count control.
- Saved projects now remember the project name and scene count.
- Added a New Project reset action.
- Preserved Stage 32 duration, aspect-ratio, narration, music, scene editing, preview, and local rendering features.

## Stage 34
- Upgraded Scene Preview to show the attached scene image when available.
- Preview now displays the scene title, image, and description together.
- Kept Stage 33 project naming, 2–30 scene control, New Project, narration, music mixing, multi-format rendering, and local project saving.

## Stage 35
- Added scene ordering controls with Up and Down buttons.
- Reordering automatically renumbers scenes and invalidates the old render so the next render follows the new order.
- Preserved Stage 34 visual scene preview and all previous project, scene, narration, music, and multi-format features.

## Stage 36
- Added one-tap scene duplication.
- Duplicated scenes keep their attached image and description, and are inserted directly after the selected scene.
- Scene numbering is automatically rebuilt after duplication.
- Maximum project size remains 30 scenes.

## Stage 37
- Added image thumbnails directly to scene cards.
- Improved rendered scene images with center-crop framing to avoid stretching.
- Updated renderer branding/footer to Stage 37.
- Preserved all Stage 36 scene management, duplication, preview, project saving, narration, music, and multi-format features.

## Stage 38
- Added an individual duration control for every scene (1–30 seconds).
- The estimated total video length updates from the scene durations.
- Rendering now uses each scene's own duration instead of one duration for every scene.
- Scene duration is saved and restored with projects.

## Stage 39
- Fixed per-scene duration persistence when saving and restoring projects.
- Fixed the local renderer so each scene actually plays for its configured duration.
- Rendering now follows the ordered cumulative scene durations instead of giving every scene equal time.
- The final rendered length is capped by the selected overall length setting.

## Stage 40
- Added Export Backup to save the current project as a portable `.tmsproject.json` file.
- Added Import Backup to restore a project from a backup file.
- Backups preserve project name, prompt, duration, format, scene order, scene images, and per-scene durations.
- Import is limited to 30 scenes and clears the previous rendered-video state.

## Stage 41
- Added per-scene duration controls (1–30 seconds).
- Added Cut, Fade, and Slide transitions between scenes.
- Transition settings are saved/restored in project backups.
- Fade and Slide transitions are applied during local rendering.

## Stage 42
- Added project-level Visual Style presets: Cinematic, Documentary, and Cartoon.
- Visual Style is saved and restored with project backups.
- The selected style is reflected in the local scene renderer.

## Stage 43
- Stability pass for the Stage 42 Visual Style renderer.
- Visual Style is now passed explicitly into scene rendering.
- Backup import now restores each scene's Cut/Fade/Slide transition.
- Locally saved projects restore the selected Cinematic/Documentary/Cartoon style.


## Stage 44
- Added working project-level Visual Style controls: Cinematic, Documentary, and Cartoon.
- Fixed the local renderer to receive the selected Visual Style explicitly.
- Extended scene timing from 1–30 seconds to 1–120 seconds.
- Build Scene Plan now distributes the selected 1–15 minute target across scenes and automatically adds enough scenes when needed to stay within the 120-second scene limit.
- Locally saved projects now restore Visual Style and Cut/Fade/Slide transitions correctly.
- Render manifests now include scene duration and transition metadata.
- Updated Android version to 0.33.0 / versionCode 33.
