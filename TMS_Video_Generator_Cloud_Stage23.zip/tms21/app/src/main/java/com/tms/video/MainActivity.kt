package com.tms.video

import android.os.Bundle
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private data class Scene(val number: Int, val title: String, val description: String)

private const val PREFS = "tms_video_generator"
private const val PROJECT_KEY = "project"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TmsVideoGeneratorApp(applicationContext) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TmsVideoGeneratorApp(context: Context) {
    var prompt by remember { mutableStateOf("") }
    var duration by remember { mutableStateOf(5) }
    var scenes by remember { mutableStateOf(listOf<Scene>()) }
    var status by remember { mutableStateOf("Ready") }
    var busy by remember { mutableStateOf(false) }
    var renderPrepared by remember { mutableStateOf(false) }
    var renderStatus by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        val saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(PROJECT_KEY, null)
        if (saved != null) {
            runCatching {
                val obj = JSONObject(saved)
                prompt = obj.optString("prompt")
                duration = obj.optInt("duration", 5).coerceIn(1, 15)
                val arr = obj.optJSONArray("scenes") ?: JSONArray()
                scenes = (0 until arr.length()).map { i ->
                    val item = arr.getJSONObject(i)
                    Scene(item.getInt("number"), item.getString("title"), item.getString("description"))
                }
                status = if (scenes.isNotEmpty()) "Saved project restored: ${scenes.size} scenes." else "Ready"
            }
        }
    }

    MaterialTheme {
        Scaffold(topBar = {
            TopAppBar(title = { Text("TMS Video Generator") })
        }) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("Create a video", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text("Describe your story, choose a length, then build the scene plan.")
                }
                item {
                    OutlinedTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp),
                        label = { Text("Video idea") },
                        placeholder = { Text("Example: A 5-minute inspirational story about never giving up") }
                    )
                }
                item {
                    Text("Length: ${duration} minute${if (duration == 1) "" else "s"}")
                    Slider(
                        value = duration.toFloat(),
                        onValueChange = { duration = it.toInt().coerceIn(1, 15) },
                        valueRange = 1f..15f,
                        steps = 13
                    )
                    Text("Choose 1–15 minutes for this build.", style = MaterialTheme.typography.bodySmall)
                }
                item {
                    Button(
                        enabled = prompt.isNotBlank() && !busy,
                        onClick = {
                            busy = true
                            status = "Building scene plan..."
                            val count = (duration * 2).coerceIn(2, 30)
                            scenes = (1..count).map { i ->
                                Scene(i, "Scene $i", "Scene ${i}: ${prompt.trim()}")
                            }
                            status = "Scene plan ready: $count scenes."
                            busy = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (busy) "Building..." else "Build Scene Plan") }
                }
                item { Text(status, style = MaterialTheme.typography.bodyMedium) }
                if (scenes.isNotEmpty()) {
                    item {
                        HorizontalDivider()
                        Text("Scenes", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    }
                    itemsIndexed(scenes) { _, scene ->
                        ElevatedCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Text(scene.title, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(4.dp))
                                Text(scene.description)
                            }
                        }
                    }
                    item {
                        OutlinedButton(
                            onClick = {
                                val obj = JSONObject().apply {
                                    put("prompt", prompt.trim())
                                    put("duration", duration)
                                    put("scenes", JSONArray().apply {
                                        scenes.forEach { scene -> put(JSONObject().apply {
                                            put("number", scene.number)
                                            put("title", scene.title)
                                            put("description", scene.description)
                                        }) }
                                    })
                                }
                                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                                    .edit().putString(PROJECT_KEY, obj.toString()).apply()
                                status = "Project saved on this device."
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Save Project") }
                    }
                    item {
                        Button(
                            enabled = !busy && scenes.isNotEmpty(),
                            onClick = {
                                busy = true
                                renderPrepared = false
                                renderStatus = "Preparing ${scenes.size} scenes for rendering..."
                                val manifest = JSONObject().apply {
                                    put("durationMinutes", duration)
                                    put("sceneCount", scenes.size)
                                    put("scenes", JSONArray().apply {
                                        scenes.forEach { scene -> put(JSONObject().apply {
                                            put("number", scene.number)
                                            put("title", scene.title)
                                            put("description", scene.description)
                                        }) }
                                    })
                                }
                                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                                    .edit().putString("render_manifest", manifest.toString()).apply()
                                renderPrepared = true
                                renderStatus = "Render manifest prepared. Video rendering engine is the next integration step."
                                busy = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (busy) "Preparing..." else "Prepare Video Render") }
                        if (renderStatus.isNotBlank()) {
                            Spacer(Modifier.height(8.dp))
                            Text(renderStatus, style = MaterialTheme.typography.bodySmall)
                        }
                        if (renderPrepared) {
                            Spacer(Modifier.height(8.dp))
                            LinearProgressIndicator(progress = { 1f }, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
                item {
                    Text(
                        "Stage 23 • Project persistence + render pipeline foundation",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }
    }
}
