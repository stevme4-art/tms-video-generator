# TMS Video Generator — Cloud Stage 21

This stage is a complete Android Studio project prepared for a cloud build.

## Goal
Build an installable debug APK through GitHub Actions without needing a PC.

## After installation
Open the app and tap **Run App Test**.

This stage deliberately verifies the Android build and app launch first. The full 30-second media renderer will be connected after the cloud build succeeds, so we do not confuse a successful APK build with a successful video render.
