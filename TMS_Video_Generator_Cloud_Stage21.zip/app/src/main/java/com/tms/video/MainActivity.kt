package com.tms.video

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                var status by remember { mutableStateOf("Ready") }
                var busy by remember { mutableStateOf(false) }
                val scope = rememberCoroutineScope()
                Scaffold(topBar = { TopAppBar(title = { Text("TMS Video Generator") }) }) { p ->
                    Column(
                        Modifier.padding(p).padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text("Stage 21 — Cloud build test", style = MaterialTheme.typography.headlineSmall)
                        Text("This build verifies that the Android project installs and launches. The next stage connects the full 30-second Media3 render pipeline.")
                        Button(
                            enabled = !busy,
                            onClick = {
                                busy = true
                                status = "Preparing test..."
                                scope.launch {
                                    kotlinx.coroutines.delay(500)
                                    status = "TMS test screen is working."
                                    busy = false
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (busy) "Testing..." else "Run App Test") }
                        Text(status)
                    }
                }
            }
        }
    }
}
