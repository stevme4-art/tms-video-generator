package com.tms.video

import android.os.Bundle
import android.content.Context
import android.os.Environment
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.media.MediaRecorder
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.net.Uri
import android.provider.MediaStore
import android.view.Surface
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.saveable.rememberSaveable
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.Effects
import androidx.media3.common.audio.GainProcessor
import androidx.media3.common.audio.DefaultGainProvider
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private data class Scene(val number: Int, val title: String, val description: String, val imageUri: String? = null, val durationSec: Int = 5, val transition: String = "Fade")

private const val PREFS = "tms_video_generator"
private const val PROJECT_KEY = "project"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TmsVideoGeneratorApp(applicationContext) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TmsVideoGeneratorApp(context: Context) {
    var projectName by rememberSaveable { mutableStateOf("My Video Project") }
    var visualStyle by rememberSaveable { mutableStateOf("Cinematic") }
    var prompt by remember { mutableStateOf("") }
    var duration by remember { mutableStateOf(5) }
    var sceneCount by rememberSaveable { mutableStateOf(10) }
    var aspectRatio by rememberSaveable { mutableStateOf("16:9") }
    var scenes by remember { mutableStateOf(listOf<Scene>()) }
    var imageSceneIndex by rememberSaveable { mutableStateOf(-1) }
    val imagePicker = androidx.activity.compose.rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null && imageSceneIndex >= 0) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            scenes = scenes.mapIndexed { index, scene -> if (index == imageSceneIndex) scene.copy(imageUri = uri.toString()) else scene }
        }
        imageSceneIndex = -1
    }
    var status by remember { mutableStateOf("Ready") }
    var busy by remember { mutableStateOf(false) }
    var renderPrepared by remember { mutableStateOf(false) }
    var renderStatus by remember { mutableStateOf("") }
    var renderProgress by remember { mutableStateOf(0f) }
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var narrationUri by remember { mutableStateOf<Uri?>(null) }
    var narrationStatus by remember { mutableStateOf("") }
    var narrationBusy by remember { mutableStateOf(false) }
    var narrationMixBusy by remember { mutableStateOf(false) }
    var narrationMixStatus by remember { mutableStateOf("") }
    var narrationScriptDialog by rememberSaveable { mutableStateOf(false) }
    var productionCheck by remember { mutableStateOf<String?>(null) }
    var musicUri by remember { mutableStateOf<Uri?>(null) }
    var musicName by remember { mutableStateOf("") }
    var musicVolume by rememberSaveable { mutableStateOf(0.25f) }
    val musicPicker = androidx.activity.compose.rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            musicUri = uri
            musicName = uri.lastPathSegment?.substringAfterLast('/')?.takeLast(42) ?: "Selected audio"
        }
    }
    val exportProjectLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            runCatching {
                val obj = JSONObject().apply {
                    put("projectName", projectName.trim().ifBlank { "My Video Project" })
                    put("prompt", prompt.trim())
                    put("duration", duration)
                    put("sceneCount", sceneCount)
                    put("aspectRatio", aspectRatio)
                                    put("visualStyle", visualStyle)
                    put("speechRate", speechRate)
                    put("speechPitch", speechPitch)
                    put("voicePreset", voicePreset)
                    put("scenes", JSONArray().apply {
                        scenes.forEach { scene ->
                            put(JSONObject().apply {
                                put("number", scene.number)
                                put("title", scene.title)
                                put("description", scene.description)
                                scene.imageUri?.let { put("imageUri", it) }
                                put("durationSec", scene.durationSec)
                                put("transition", scene.transition)
                            })
                        }
                    })
                }
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(obj.toString(2).toByteArray(Charsets.UTF_8))
                } ?: error("Could not open export file")
                status = "Project backup exported."
            }.onFailure { error ->
                status = "Export failed: ${error.message ?: "Unknown error"}"
            }
        }
    }

    val importProjectLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                val json = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: error("Could not read project backup")
                val obj = JSONObject(json)
                projectName = obj.optString("projectName", "My Video Project").ifBlank { "My Video Project" }
                prompt = obj.optString("prompt")
                duration = obj.optInt("duration", 5).coerceIn(1, 15)
                aspectRatio = obj.optString("aspectRatio", "16:9").let {
                    if (it in listOf("16:9", "9:16", "1:1")) it else "16:9"
                }
                visualStyle = obj.optString("visualStyle", "Cinematic").let {
                    if (it in listOf("Cinematic", "Documentary", "Cartoon")) it else "Cinematic"
                }
                speechRate = obj.optDouble("speechRate", 1.0).toFloat().coerceIn(0.5f, 1.5f)
                speechPitch = obj.optDouble("speechPitch", 1.0).toFloat().coerceIn(0.5f, 1.5f)
                voicePreset = obj.optString("voicePreset", "Storyteller").let {
                    if (it in listOf("Calm", "Storyteller", "Energetic", "Deep")) it else "Storyteller"
                }
                val arr = obj.optJSONArray("scenes") ?: JSONArray()
                scenes = (0 until arr.length()).map { i ->
                    val item = arr.getJSONObject(i)
                    Scene(
                        i + 1,
                        item.optString("title", "Scene ${i + 1}"),
                        item.optString("description", ""),
                        item.optString("imageUri").takeIf { it.isNotBlank() },
                        item.optInt("durationSec", 5).coerceIn(1, 120),
                        item.optString("transition", "Fade").let {
                            if (it in listOf("Cut", "Fade", "Slide")) it else "Fade"
                        }
                    )
                }.take(30)
                sceneCount = scenes.size.coerceIn(2, 30)
                videoUri = null
                renderPrepared = false
                status = "Project backup imported: ${scenes.size} scenes."
            }.onFailure { error ->
                status = "Import failed: ${error.message ?: "Invalid project file"}"
            }
        }
    }

    var speechRate by rememberSaveable { mutableStateOf(1.0f) }
    var speechPitch by rememberSaveable { mutableStateOf(1.0f) }
    var voicePreset by rememberSaveable { mutableStateOf("Storyteller") }
    var voicePreviewBusy by rememberSaveable { mutableStateOf(false) }
    var voicePreviewStatus by rememberSaveable { mutableStateOf("") }
    var voicePreviewTts by remember { mutableStateOf<TextToSpeech?>(null) }
    var voicePreviewText by rememberSaveable { mutableStateOf("Hello. This is a preview of your selected narration voice.") }
    var editSceneIndex by rememberSaveable { mutableStateOf(-1) }
    var previewSceneIndex by rememberSaveable { mutableStateOf(-1) }
    var editTitle by rememberSaveable { mutableStateOf("") }
    var editDescription by rememberSaveable { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        val saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(PROJECT_KEY, null)
        if (saved != null) {
            runCatching {
                val obj = JSONObject(saved)
                projectName = obj.optString("projectName", "My Video Project").ifBlank { "My Video Project" }
                prompt = obj.optString("prompt")
                duration = obj.optInt("duration", 5).coerceIn(1, 15)
                sceneCount = obj.optInt("sceneCount", (duration * 2).coerceIn(2, 30)).coerceIn(2, 30)
                visualStyle = obj.optString("visualStyle", "Cinematic").let { if (it in listOf("Cinematic", "Documentary", "Cartoon")) it else "Cinematic" }
                aspectRatio = obj.optString("aspectRatio", "16:9").let { if (it in listOf("16:9", "9:16", "1:1")) it else "16:9" }
                speechRate = obj.optDouble("speechRate", 1.0).toFloat().coerceIn(0.5f, 1.5f)
                speechPitch = obj.optDouble("speechPitch", 1.0).toFloat().coerceIn(0.5f, 1.5f)
                voicePreset = obj.optString("voicePreset", "Storyteller").let { if (it in listOf("Calm", "Storyteller", "Energetic", "Deep")) it else "Storyteller" }
                val arr = obj.optJSONArray("scenes") ?: JSONArray()
                scenes = (0 until arr.length()).map { i ->
                    val item = arr.getJSONObject(i)
                    Scene(
                        item.getInt("number"),
                        item.getString("title"),
                        item.getString("description"),
                        item.optString("imageUri").takeIf { it.isNotBlank() },
                        item.optInt("durationSec", 5).coerceIn(1, 120),
                        item.optString("transition", "Fade").let { if (it in listOf("Cut", "Fade", "Slide")) it else "Fade" }
                    )
                }
                status = if (scenes.isNotEmpty()) "Saved project restored: ${scenes.size} scenes." else "Ready"
            }
        }
    }

    MaterialTheme {
        Scaffold(topBar = {
            TopAppBar(title = { Text("TMS Video Generator") })
        }) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("Create a video", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text("Describe your story, choose a length, then build the scene plan.")
                }
                item {
                    OutlinedTextField(
                        value = projectName,
                        onValueChange = { projectName = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Project name") },
                        singleLine = true
                    )
                }
                item {
                    OutlinedTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp),
                        label = { Text("Video idea") },
                        placeholder = { Text("Example: A 5-minute inspirational story about never giving up") }
                    )
                }
                item {
                    Text("Length: ${duration} minute${if (duration == 1) "" else "s"}")
                    Slider(
                        value = duration.toFloat(),
                        onValueChange = { duration = it.toInt().coerceIn(1, 15) },
                        valueRange = 1f..15f,
                        steps = 13
                    )
                    Text("Choose 1–15 minutes for this build.", style = MaterialTheme.typography.bodySmall)
                }
                item {
                    Text("Scenes: $sceneCount", fontWeight = FontWeight.Bold)
                    Slider(
                        value = sceneCount.toFloat(),
                        onValueChange = { sceneCount = it.toInt().coerceIn(2, 30) },
                        valueRange = 2f..30f,
                        steps = 27
                    )
                    Text("Choose 2–30 scenes independently of video length.", style = MaterialTheme.typography.bodySmall)
                }
                item {
                    if (scenes.isNotEmpty()) {
                        val total = scenes.sumOf { it.durationSec }
                        Text(
                            "Estimated video length: ${total}s (${total / 60}m ${total % 60}s)",
                            fontWeight = FontWeight.Bold
                        )
                        val targetSeconds = duration * 60
                        if (total != targetSeconds) {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "Target: ${duration}m. Adjust the scene durations to match the target exactly.",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Spacer(Modifier.height(6.dp))
                            OutlinedButton(
                                enabled = !busy,
                                onClick = {
                                    scenes = fitScenesToTarget(scenes, targetSeconds)
                                    videoUri = null
                                    renderPrepared = false
                                    val fittedTotal = scenes.sumOf { it.durationSec }
                                    status = if (fittedTotal == targetSeconds) {
                                        "Scene durations matched to the ${duration}-minute target."
                                    } else {
                                        "Some scenes reached the 120-second limit. Use Optimize Scene Count to match the target exactly."
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Match Scene Durations") }
                            Spacer(Modifier.height(6.dp))
                            OutlinedButton(
                                enabled = !busy,
                                onClick = {
                                    val needed = kotlin.math.ceil(targetSeconds / 120.0).toInt().coerceAtLeast(2)
                                    val desiredCount = maxOf(scenes.size, needed).coerceIn(2, 30)
                                    val expanded = if (scenes.size < desiredCount) {
                                        val seedDescription = scenes.lastOrNull()?.description ?: prompt.trim()
                                        scenes + (scenes.size + 1..desiredCount).map { number ->
                                            Scene(number, "Scene $number", if (seedDescription.isBlank()) "Scene $number" else seedDescription)
                                        }
                                    } else {
                                        scenes
                                    }
                                    val renumbered = expanded.mapIndexed { index, scene -> scene.copy(number = index + 1) }
                                    scenes = fitScenesToTarget(renumbered, targetSeconds)
                                    sceneCount = scenes.size.coerceIn(2, 30)
                                    videoUri = null
                                    renderPrepared = false
                                    status = "Optimized to ${scenes.size} scenes and matched to ${duration} minute${if (duration == 1) "" else "s"}."
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Optimize Scene Count & Match Target") }
                        } else {
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "✓ Scene durations match the selected target length.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
                item {
                    Text("Video format", fontWeight = FontWeight.Bold)
                    Text("Choose the format for YouTube, TikTok, Reels, or square posts.", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("16:9", "9:16", "1:1").forEach { ratio ->
                            FilterChip(
                                selected = aspectRatio == ratio,
                                onClick = { aspectRatio = ratio },
                                label = { Text(ratio) }
                            )
                        }
                    }
                }
                item {
                    Text("Visual style", fontWeight = FontWeight.Bold)
                    Text("Choose the look used when the video is rendered.", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Cinematic", "Documentary", "Cartoon").forEach { style ->
                            FilterChip(
                                selected = visualStyle == style,
                                onClick = { visualStyle = style; videoUri = null; renderPrepared = false },
                                label = { Text(style) }
                            )
                        }
                    }
                }
                item {
                    Button(
                        enabled = prompt.isNotBlank() && !busy,
                        onClick = {
                            busy = true
                            status = "Building scene plan..."
                            val requestedCount = sceneCount.coerceIn(2, 30)
                            val targetSeconds = duration * 60
                            val count = maxOf(requestedCount, kotlin.math.ceil(targetSeconds / 120.0).toInt()).coerceIn(2, 30)
                            sceneCount = count
                            val baseSeconds = targetSeconds / count
                            val remainder = targetSeconds % count
                            scenes = (1..count).map { i ->
                                val sceneSeconds = baseSeconds + if (i <= remainder) 1 else 0
                                Scene(i, "Scene $i", "Scene ${i}: ${prompt.trim()}", durationSec = sceneSeconds.coerceIn(1, 120))
                            }
                            status = "Scene plan ready: $count scenes covering about ${targetSeconds / 60}m ${targetSeconds % 60}s."
                            busy = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (busy) "Building..." else "Build Scene Plan") }
                }
                item {
                    OutlinedButton(
                        enabled = scenes.isNotEmpty() && prompt.isNotBlank() && !busy,
                        onClick = {
                            scenes = buildSmartStoryboard(scenes, prompt.trim(), visualStyle)
                            videoUri = null
                            renderPrepared = false
                            status = "Smart storyboard created for ${scenes.size} scenes."
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("✨ Enhance Storyboard") }
                    Text(
                        "Creates stronger scene titles and descriptions from your video idea. This is local and does not require an AI service.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                item {
                    OutlinedButton(
                        enabled = scenes.isNotEmpty() && !busy,
                        onClick = { productionCheck = productionReadinessReport(scenes, prompt, duration) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("✓ Production Readiness Check") }
                    Text(
                        "Checks timing, scene coverage, descriptions, and missing media before rendering.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                item {
                    OutlinedButton(
                        enabled = scenes.isNotEmpty() && !busy,
                        onClick = { productionCheck = narrationTimingReport(scenes, speechRate) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("🎙 Narration Timing Check") }
                    Text(
                        "Estimates narration length from scene descriptions and flags scenes that may need more time.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                item {
                    OutlinedButton(
                        enabled = scenes.isNotEmpty() && !busy,
                        onClick = {
                            scenes = fitScenesToNarration(scenes, speechRate, duration * 60)
                            videoUri = null
                            renderPrepared = false
                            status = "Scene timings fitted to estimated narration."
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("⏱ Auto-Fit Narration Timing") }
                    Text(
                        "Automatically adjusts scene durations toward the estimated narration while respecting the 1–120 second scene limit and target length.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                item { Text(status, style = MaterialTheme.typography.bodyMedium) }
                if (scenes.isNotEmpty()) {
                    item {
                        HorizontalDivider()
                        Text("Scenes", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    }
                    itemsIndexed(scenes) { _, scene ->
                        ElevatedCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Text(scene.title, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(4.dp))
                                Text(scene.description)
                                Spacer(Modifier.height(8.dp))
                                Text("Duration: ${scene.durationSec}s", fontWeight = FontWeight.Bold)
                                Slider(
                                    value = scene.durationSec.toFloat(),
                                    onValueChange = { value ->
                                        scenes = scenes.map {
                                            if (it.number == scene.number) it.copy(durationSec = value.toInt().coerceIn(1, 120)) else it
                                        }
                                        videoUri = null
                                        renderPrepared = false
                                    },
                                    valueRange = 1f..120f,
                                    steps = 118
                                )
                                Text("Transition to next scene", fontWeight = FontWeight.Bold)
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    listOf("Cut", "Fade", "Slide").forEach { option ->
                                        FilterChip(
                                            selected = scene.transition == option,
                                            onClick = {
                                                scenes = scenes.map {
                                                    if (it.number == scene.number) it.copy(transition = option) else it
                                                }
                                                videoUri = null
                                                renderPrepared = false
                                            },
                                            label = { Text(option) }
                                        )
                                    }
                                }
                                Spacer(Modifier.height(8.dp))
                                OutlinedButton(onClick = {
                                    imageSceneIndex = scene.number - 1
                                    imagePicker.launch(arrayOf("image/*"))
                                }) {
                                    Text(if (scene.imageUri == null) "Add Scene Image" else "Change Scene Image")
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        enabled = scene.number > 1 && !busy,
                                        onClick = {
                                            val index = scene.number - 1
                                            val updated = scenes.toMutableList()
                                            val moved = updated.removeAt(index)
                                            updated.add(index - 1, moved)
                                            scenes = updated.mapIndexed { i, item -> item.copy(number = i + 1) }
                                            videoUri = null
                                            renderPrepared = false
                                            status = "Scene moved up."
                                        }
                                    ) { Text("↑ Up") }
                                    OutlinedButton(
                                        enabled = scene.number < scenes.size && !busy,
                                        onClick = {
                                            val index = scene.number - 1
                                            val updated = scenes.toMutableList()
                                            val moved = updated.removeAt(index)
                                            updated.add(index + 1, moved)
                                            scenes = updated.mapIndexed { i, item -> item.copy(number = i + 1) }
                                            videoUri = null
                                            renderPrepared = false
                                            status = "Scene moved down."
                                        }
                                    ) { Text("↓ Down") }
                                    OutlinedButton(onClick = {
                                        editSceneIndex = scene.number - 1
                                        editTitle = scene.title
                                        editDescription = scene.description
                                    }) { Text("Edit") }
                                    OutlinedButton(onClick = { previewSceneIndex = scene.number - 1 }) { Text("Preview") }
                                    OutlinedButton(
                                        enabled = scenes.size < 30 && !busy,
                                        onClick = {
                                            val index = scene.number - 1
                                            val copy = scene.copy(number = index + 2, title = "${scene.title} Copy")
                                            scenes = scenes.toMutableList().apply { add(index + 1, copy) }
                                                .mapIndexed { i, item -> item.copy(number = i + 1) }
                                            videoUri = null
                                            renderPrepared = false
                                            status = "Scene duplicated. ${scenes.size} scenes total."
                                        }
                                    ) { Text("Duplicate") }
                                    OutlinedButton(onClick = {
                                        scenes = scenes.filterIndexed { index, _ -> index != scene.number - 1 }
                                            .mapIndexed { index, item -> item.copy(number = index + 1) }
                                        status = "Scene removed. ${scenes.size} scenes remain."
                                        videoUri = null
                                        renderPrepared = false
                                    }) { Text("Delete") }
                                    if (scene.imageUri != null) {
                                        OutlinedButton(onClick = {
                                            scenes = scenes.mapIndexed { index, item ->
                                                if (index == scene.number - 1) item.copy(imageUri = null) else item
                                            }
                                        }) { Text("Remove Image") }
                                    }
                                }
                                if (scene.imageUri != null) {
                                    val thumbnail = remember(scene.imageUri) {
                                        runCatching {
                                            context.contentResolver.openInputStream(Uri.parse(scene.imageUri)).use { input ->
                                                BitmapFactory.decodeStream(input)
                                            }
                                        }.getOrNull()
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    if (thumbnail != null) {
                                        androidx.compose.foundation.Image(
                                            bitmap = thumbnail.asImageBitmap(),
                                            contentDescription = "Thumbnail for ${scene.title}",
                                            modifier = Modifier.fillMaxWidth().heightIn(max = 180.dp)
                                        )
                                    }
                                    Text("Image attached", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                    item {
                        OutlinedButton(
                            enabled = scenes.size < 30,
                            onClick = {
                                val nextNumber = scenes.size + 1
                                scenes = scenes + Scene(
                                    nextNumber,
                                    "Scene $nextNumber",
                                    "Add a description for scene $nextNumber"
                                )
                                status = "Scene $nextNumber added."
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (scenes.size < 30) "Add Scene" else "Maximum 30 Scenes") }
                    }
                    item {
                        OutlinedButton(
                            onClick = {
                                val obj = JSONObject().apply {
                                    put("projectName", projectName.trim().ifBlank { "My Video Project" })
                                    put("prompt", prompt.trim())
                                    put("duration", duration)
                                    put("sceneCount", sceneCount)
                                    put("aspectRatio", aspectRatio)
                                    put("visualStyle", visualStyle)
                                    put("speechRate", speechRate)
                                    put("speechPitch", speechPitch)
                                    put("voicePreset", voicePreset)
                                    put("scenes", JSONArray().apply {
                                        scenes.forEach { scene -> put(JSONObject().apply {
                                            put("number", scene.number)
                                            put("title", scene.title)
                                            put("description", scene.description)
                                            scene.imageUri?.let { put("imageUri", it) }
                                            put("durationSec", scene.durationSec)
                                put("transition", scene.transition)
                                        }) }
                                    })
                                }
                                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                                    .edit().putString(PROJECT_KEY, obj.toString()).apply()
                                status = "Project saved on this device."
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Save Project") }
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(
                                enabled = !busy,
                                onClick = {
                                    val safeName = projectName.trim().ifBlank { "My Video Project" }
                                        .replace(Regex("[^A-Za-z0-9_-]+"), "_")
                                    exportProjectLauncher.launch("$safeName.tmsproject.json")
                                },
                                modifier = Modifier.weight(1f)
                            ) { Text("Export Backup") }
                            OutlinedButton(
                                enabled = !busy,
                                onClick = { importProjectLauncher.launch(arrayOf("application/json", "text/*")) },
                                modifier = Modifier.weight(1f)
                            ) { Text("Import Backup") }
                        }
                    }
                    item {
                        OutlinedButton(
                            enabled = !busy,
                            onClick = {
                                projectName = "My Video Project"
                                prompt = ""
                                duration = 5
                                sceneCount = 10
                                speechRate = 1.0f
                                speechPitch = 1.0f
                                voicePreset = "Storyteller"
                                voicePreviewStatus = ""
                                scenes = emptyList()
                                videoUri = null
                                narrationUri = null
                                musicUri = null
                                status = "New project started."
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("New Project") }
                    }
                    item {
                        Button(
                            enabled = !busy && scenes.isNotEmpty(),
                            onClick = {
                                busy = true
                                renderPrepared = false
                                renderProgress = 0f
                                videoUri = null
                                renderStatus = "Preparing local video renderer..."
                                val manifest = JSONObject().apply {
                                    put("durationMinutes", duration)
                                    put("aspectRatio", aspectRatio)
                                    put("visualStyle", visualStyle)
                                    put("sceneCount", scenes.size)
                                    put("scenes", JSONArray().apply {
                                        scenes.forEach { scene -> put(JSONObject().apply {
                                            put("number", scene.number)
                                            put("title", scene.title)
                                            put("description", scene.description)
                                            scene.imageUri?.let { put("imageUri", it) }
                                            put("durationSec", scene.durationSec)
                                            put("transition", scene.transition)
                                        }) }
                                    })
                                }
                                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                                    .edit().putString("render_manifest", manifest.toString()).apply()
                                renderPrepared = true
                                scope.launch {
                                    runCatching {
                                        renderVideoLocally(context, scenes, duration, aspectRatio, visualStyle) { progress, message ->
                                            renderProgress = progress
                                            renderStatus = message
                                        }
                                    }.onSuccess { uri ->
                                        videoUri = uri
                                        renderProgress = 1f
                                        renderStatus = "Video draft ready. Saved to your device."
                                    }.onFailure { error ->
                                        renderStatus = "Render failed: ${error.message ?: "Unknown error"}"
                                    }
                                    busy = false
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (busy) "Rendering Video..." else "Render Video") }
                        if (renderStatus.isNotBlank()) {
                            Spacer(Modifier.height(8.dp))
                            Text(renderStatus, style = MaterialTheme.typography.bodySmall)
                        }
                        if (renderPrepared) {
                            Spacer(Modifier.height(8.dp))
                            LinearProgressIndicator(progress = { renderProgress }, modifier = Modifier.fillMaxWidth())
                            Spacer(Modifier.height(4.dp))
                            Text("${(renderProgress * 100).toInt()}%", style = MaterialTheme.typography.labelSmall)
                        }
                        if (videoUri != null) {
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = { shareVideo(context, videoUri!!) },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Share Video") }
                        }
                    }
                    item {
                        HorizontalDivider()
                        Text("Narration", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Voice settings", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Speech rate: ${String.format(Locale.US, "%.1fx", speechRate)}")
                        Slider(value = speechRate, onValueChange = { speechRate = it }, valueRange = 0.5f..1.5f)
                        Text("Pitch: ${String.format(Locale.US, "%.1fx", speechPitch)}")
                        Slider(value = speechPitch, onValueChange = { speechPitch = it }, valueRange = 0.5f..1.5f)
                        Text("Voice preset: $voicePreset", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Calm", "Storyteller", "Energetic", "Deep").forEach { preset ->
                                FilterChip(
                                    selected = voicePreset == preset,
                                    onClick = {
                                        voicePreset = preset
                                        when (preset) {
                                            "Calm" -> { speechRate = 0.85f; speechPitch = 0.9f }
                                            "Storyteller" -> { speechRate = 1.0f; speechPitch = 1.0f }
                                            "Energetic" -> { speechRate = 1.2f; speechPitch = 1.1f }
                                            "Deep" -> { speechRate = 0.9f; speechPitch = 0.75f }
                                        }
                                    },
                                    label = { Text(preset) }
                                )
                            }
                        }
                        Text(
                            "Presets quickly tune the phone's built-in voice; you can still fine-tune rate and pitch above.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(Modifier.height(6.dp))
                        OutlinedTextField(
                            value = voicePreviewText,
                            onValueChange = { voicePreviewText = it.take(500) },
                            label = { Text("Preview text") },
                            supportingText = { Text("Type up to 500 characters to test the voice.") },
                            minLines = 2,
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !voicePreviewBusy
                        )
                        if (!voicePreviewBusy && voicePreviewText.isNotBlank()) {
                            OutlinedButton(
                                onClick = {
                                    voicePreviewText = ""
                                    voicePreviewStatus = "Preview text cleared."
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("🧹 Clear Preview Text") }
                            Spacer(Modifier.height(4.dp))
                        }
                        OutlinedButton(
                            enabled = !voicePreviewBusy && voicePreviewText.isNotBlank(),
                            onClick = {
                                voicePreviewBusy = true
                                voicePreviewStatus = "Testing $voicePreset voice..."
                                previewVoice(
                                    context,
                                    voicePreviewText.trim(),
                                    speechRate,
                                    speechPitch,
                                    scope,
                                    onStarted = { tts -> voicePreviewTts = tts },
                                    onComplete = {
                                        voicePreviewTts = null
                                        voicePreviewBusy = false
                                        voicePreviewStatus = "Voice preview finished."
                                    },
                                    onError = { message ->
                                        voicePreviewTts = null
                                        voicePreviewBusy = false
                                        voicePreviewStatus = message
                                    }
                                )
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("🔊 Preview Voice") }
                        if (voicePreviewBusy) {
                            OutlinedButton(
                                onClick = {
                                    voicePreviewTts?.stop()
                                    voicePreviewTts?.shutdown()
                                    voicePreviewTts = null
                                    voicePreviewBusy = false
                                    voicePreviewStatus = "Voice preview stopped."
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("⏹ Stop Voice Preview") }
                        }
                        if (voicePreviewStatus.isNotBlank()) {
                            Spacer(Modifier.height(4.dp))
                            Text(voicePreviewStatus, style = MaterialTheme.typography.bodySmall)
                        }
                        
                        Spacer(Modifier.height(4.dp))
                        OutlinedButton(
                            enabled = scenes.isNotEmpty() && !narrationBusy,
                            onClick = { narrationScriptDialog = true },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("📜 Preview Narration Script") }
                        Text(
                            "Review the complete scene-by-scene narration before generating audio.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(Modifier.height(4.dp))
                        Text("Create a voice narration from your scene text using the phone's built-in text-to-speech engine.")
                        Spacer(Modifier.height(8.dp))
                        Button(
                            enabled = scenes.isNotEmpty() && !narrationBusy,
                            onClick = {
                                narrationBusy = true
                                narrationUri = null
                                narrationStatus = "Preparing narration..."
                                val text = scenes.joinToString("\n\n") { scene ->
                                    "Scene ${scene.number}. ${scene.title}. ${scene.description}"
                                }
                                generateNarration(context, text, speechRate, speechPitch, scope,
                                    onStatus = { message -> narrationStatus = message },
                                    onComplete = { uri ->
                                        narrationUri = uri
                                        narrationBusy = false
                                        narrationStatus = "Narration audio ready on your device."
                                    },
                                    onError = { message ->
                                        narrationBusy = false
                                        narrationStatus = message
                                    })
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (narrationBusy) "Generating Narration..." else "Generate Narration") }
                        if (narrationStatus.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text(narrationStatus, style = MaterialTheme.typography.bodySmall)
                        }
                        if (narrationUri != null) {
                            Spacer(Modifier.height(6.dp))
                            OutlinedButton(
                                onClick = { shareAudio(context, narrationUri!!) },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Share Narration Audio") }
                        }
                        HorizontalDivider()
                        Text("Background Music", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Optionally add music from your phone. The track will loop to cover the video length.", style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(6.dp))
                        OutlinedButton(
                            onClick = { musicPicker.launch(arrayOf("audio/*")) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (musicUri == null) "Choose Background Music" else "Change Background Music") }
                        if (musicUri != null) {
                            Text("Music: $musicName", style = MaterialTheme.typography.labelSmall)
                            Text("Music volume: ${(musicVolume * 100).toInt()}%")
                            Slider(value = musicVolume, onValueChange = { musicVolume = it }, valueRange = 0f..1f)
                            OutlinedButton(
                                onClick = { musicUri = null; musicName = "" },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Remove Background Music") }
                        }
                        if (videoUri != null && (narrationUri != null || musicUri != null)) {
                            Spacer(Modifier.height(8.dp))
                            Button(
                                enabled = !narrationMixBusy,
                                onClick = {
                                    narrationMixBusy = true
                                    narrationMixStatus = "Preparing final audio mix..."
                                    mixAudioIntoVideo(
                                        context = context,
                                        videoUri = videoUri!!,
                                        narrationUri = narrationUri,
                                        musicUri = musicUri,
                                        musicVolume = musicVolume,
                                        durationMinutes = duration,
                                        onStatus = { message -> narrationMixStatus = message },
                                        onComplete = { uri ->
                                            narrationMixBusy = false
                                            narrationMixStatus = "Final video with audio is ready."
                                            videoUri = uri
                                        },
                                        onError = { message ->
                                            narrationMixBusy = false
                                            narrationMixStatus = message
                                        }
                                    )
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(if (narrationMixBusy) "Creating Final Video..." else "Create Video With Audio")
                            }
                            if (narrationMixStatus.isNotBlank()) {
                                Spacer(Modifier.height(6.dp))
                                Text(narrationMixStatus, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                item {
                    Text(
                        "Stage 54 • Voice settings saved/restored + voice preview + narration script preview + auto-fit timing + storyboard + transitions + backups + local rendering",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
                if (editSceneIndex >= 0) {
                    item {
                        AlertDialog(
                            onDismissRequest = { editSceneIndex = -1 },
                            title = { Text("Edit Scene ${editSceneIndex + 1}") },
                            text = {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    OutlinedTextField(value = editTitle, onValueChange = { editTitle = it }, label = { Text("Title") })
                                    OutlinedTextField(value = editDescription, onValueChange = { editDescription = it }, label = { Text("Description") }, minLines = 4)
                                }
                            },
                            confirmButton = {
                                Button(onClick = {
                                    scenes = scenes.mapIndexed { index, item ->
                                        if (index == editSceneIndex) item.copy(title = editTitle.trim().ifBlank { "Scene ${index + 1}" }, description = editDescription.trim()) else item
                                    }
                                    val savedSceneNumber = editSceneIndex + 1
                                    editSceneIndex = -1
                                    status = "Scene $savedSceneNumber updated."
                                }) { Text("Save") }
                            },
                            dismissButton = { OutlinedButton(onClick = { editSceneIndex = -1 }) { Text("Cancel") } }
                        )
                    }
                }
                if (previewSceneIndex >= 0 && previewSceneIndex < scenes.size) {
                    val preview = scenes[previewSceneIndex]
                    val previewBitmap = remember(preview.imageUri) {
                        preview.imageUri?.let { raw ->
                            runCatching {
                                context.contentResolver.openInputStream(Uri.parse(raw)).use { input ->
                                    BitmapFactory.decodeStream(input)
                                }
                            }.getOrNull()
                        }
                    }
                    item {
                        AlertDialog(
                            onDismissRequest = { previewSceneIndex = -1 },
                            title = { Text("Preview • ${preview.title}") },
                            text = {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    if (previewBitmap != null) {
                                        androidx.compose.foundation.Image(
                                            bitmap = previewBitmap.asImageBitmap(),
                                            contentDescription = "Preview image for ${preview.title}",
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .heightIn(max = 240.dp)
                                        )
                                    } else {
                                        Text(
                                            "No scene image attached yet.",
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                    Text(preview.description)
                                }
                            },
                            confirmButton = {
                                Button(onClick = { previewSceneIndex = -1 }) { Text("Close") }
                            }
                        )
                    }
                }
            }
        }
        if (narrationScriptDialog) {
            val script = buildNarrationScript(scenes)
            AlertDialog(
                onDismissRequest = { narrationScriptDialog = false },
                title = { Text("Narration Script") },
                text = { Text(script) },
                confirmButton = {
                    Button(onClick = { narrationScriptDialog = false }) { Text("Close") }
                }
            )
        }
        productionCheck?.let { report ->
            AlertDialog(
                onDismissRequest = { productionCheck = null },
                title = { Text("Production Readiness") },
                text = { Text(report) },
                confirmButton = {
                    Button(onClick = { productionCheck = null }) { Text("Close") }
                }
            )
        }
    }
}

private fun buildNarrationScript(scenes: List<Scene>): String {
    if (scenes.isEmpty()) return "No scenes available yet."
    return scenes.joinToString("\n\n") { scene ->
        "Scene ${scene.number} — ${scene.title}\n${scene.description.trim().ifBlank { "No narration text provided." }}"
    }
}

private fun fitScenesToNarration(scenes: List<Scene>, speechRate: Float, targetSeconds: Int): List<Scene> {
    if (scenes.isEmpty()) return scenes
    val wordsPerMinute = (150f * speechRate.coerceIn(0.5f, 1.5f)).coerceAtLeast(1f)
    val estimates = scenes.map { scene ->
        val words = scene.description.trim().split(Regex("\\s+")).count { it.isNotBlank() }
        if (words == 0) 5 else kotlin.math.ceil(words / wordsPerMinute * 60.0).toInt().coerceIn(3, 120)
    }
    val target = targetSeconds.coerceIn(scenes.size, scenes.size * 120)
    var durations = estimates.map { it.coerceIn(1, 120) }.toMutableList()
    var total = durations.sum()
    if (total < target) {
        var index = 0
        while (total < target) {
            if (durations[index] < 120) { durations[index]++; total++ }
            index = (index + 1) % durations.size
            if (durations.all { it >= 120 }) break
        }
    } else if (total > target) {
        var index = 0
        while (total > target) {
            if (durations[index] > 1) { durations[index]--; total-- }
            index = (index + 1) % durations.size
            if (durations.all { it <= 1 }) break
        }
    }
    return scenes.mapIndexed { index, scene -> scene.copy(durationSec = durations[index].coerceIn(1, 120)) }
}

private fun narrationTimingReport(scenes: List<Scene>, speechRate: Float): String {
    val wordsPerMinute = (150f * speechRate.coerceIn(0.5f, 1.5f)).coerceAtLeast(1f)
    var totalWords = 0
    var totalEstimatedSeconds = 0.0
    val sceneLines = mutableListOf<String>()
    scenes.forEachIndexed { index, scene ->
        val words = scene.description.trim().split(Regex("\\s+")).count { it.isNotBlank() }
        val estimated = if (words == 0) 0.0 else words / wordsPerMinute * 60.0
        totalWords += words
        totalEstimatedSeconds += estimated
        val gap = estimated - scene.durationSec
        if (words > 0 && gap > 2.0) {
            sceneLines += "• Scene ${index + 1}: narration ~${kotlin.math.ceil(estimated).toInt()}s vs ${scene.durationSec}s (${kotlin.math.ceil(gap).toInt()}s short)."
        }
    }
    return buildString {
        appendLine("Estimated narration: ${kotlin.math.ceil(totalEstimatedSeconds).toInt()}s")
        appendLine("Words: $totalWords")
        appendLine("Speech rate: ${String.format(Locale.US, "%.1fx", speechRate)}")
        if (sceneLines.isEmpty()) {
            append("✓ Narration should fit the current scene timings.")
        } else {
            appendLine("\nScenes to review:")
            sceneLines.take(10).forEach { appendLine(it) }
            if (sceneLines.size > 10) append("• ${sceneLines.size - 10} more scene(s) may need review.")
        }
    }
}

private fun productionReadinessReport(scenes: List<Scene>, prompt: String, targetMinutes: Int): String {
    val totalSeconds = scenes.sumOf { it.durationSec.coerceIn(1, 120) }
    val targetSeconds = targetMinutes.coerceIn(1, 15) * 60
    val durationDelta = totalSeconds - targetSeconds
    val emptyDescriptions = scenes.count { it.description.isBlank() }
    val missingImages = scenes.count { it.imageUri.isNullOrBlank() }
    val longScenes = scenes.count { it.durationSec > 120 }
    val issues = mutableListOf<String>()
    if (prompt.isBlank()) issues += "• Add a video idea/prompt."
    if (emptyDescriptions > 0) issues += "• $emptyDescriptions scene(s) have no description."
    if (longScenes > 0) issues += "• $longScenes scene(s) exceed the 120-second limit."
    if (durationDelta != 0) {
        val sign = if (durationDelta > 0) "+" else ""
        issues += "• Timeline is ${sign}${durationDelta}s from the ${targetMinutes}-minute target. Use Match Scenes to Target."
    }
    val timing = "Timeline: ${totalSeconds / 60}m ${totalSeconds % 60}s / target ${targetMinutes}m 0s"
    val media = "Scene images attached: ${scenes.size - missingImages}/${scenes.size}"
    return buildString {
        appendLine(timing)
        appendLine(media)
        appendLine("Scenes: ${scenes.size}")
        if (issues.isEmpty()) {
            append("✓ Ready for the next render step.")
        } else {
            appendLine("\nItems to review:")
            issues.forEach { appendLine(it) }
        }
    }
}

private fun buildSmartStoryboard(scenes: List<Scene>, prompt: String, visualStyle: String): List<Scene> {
    if (scenes.isEmpty()) return scenes
    val beats = listOf(
        "Hook", "Setup", "The Challenge", "First Turning Point", "Rising Action",
        "Discovery", "The Big Decision", "Climax", "Resolution", "Final Message"
    )
    val styleLine = when (visualStyle) {
        "Documentary" -> "Grounded documentary visuals, realistic details, natural atmosphere."
        "Cartoon" -> "Expressive cartoon visuals, clear characters, playful but readable action."
        else -> "Cinematic visuals, dramatic composition, strong atmosphere and lighting."
    }
    return scenes.mapIndexed { index, scene ->
        val beat = beats[index.coerceAtMost(beats.lastIndex)]
        val title = "$beat — Scene ${index + 1}"
        val description = when {
            scenes.size == 1 -> "$prompt. $styleLine"
            index == 0 -> "Open with an engaging visual hook for: $prompt. $styleLine"
            index == scenes.lastIndex -> "Bring $prompt to a satisfying conclusion and leave the viewer with a clear final message. $styleLine"
            else -> "Develop the story of $prompt through the $beat, showing clear action, emotion, and progression. $styleLine"
        }
        scene.copy(title = title, description = description)
    }
}

private fun fitScenesToTarget(scenes: List<Scene>, targetSeconds: Int): List<Scene> {
    if (scenes.isEmpty()) return scenes
    val target = targetSeconds.coerceAtLeast(scenes.size)
    val count = scenes.size
    val base = target / count
    val remainder = target % count
    return scenes.mapIndexed { index, scene ->
        scene.copy(durationSec = (base + if (index < remainder) 1 else 0).coerceIn(1, 120))
    }
}

private suspend fun renderVideoLocally(
    context: Context,
    scenes: List<Scene>,
    durationMinutes: Int,
    aspectRatio: String,
    visualStyle: String,
    onProgress: (Float, String) -> Unit
): Uri = withContext(Dispatchers.Default) {
    require(scenes.isNotEmpty()) { "No scenes to render" }

    val output = createVideoOutput(context)
    val recorder = MediaRecorder()
    var surface: Surface? = null
    try {
        recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE)
        recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
        val (videoWidth, videoHeight) = when (aspectRatio) {
            "9:16" -> 720 to 1280
            "1:1" -> 720 to 720
            else -> 1280 to 720
        }
        recorder.setVideoSize(videoWidth, videoHeight)
        recorder.setVideoFrameRate(10)
        recorder.setVideoEncodingBitRate(2_500_000)
        recorder.setOutputFile(output.filePath)
        recorder.prepare()
        surface = recorder.surface
        recorder.start()

        val requestedSeconds = durationMinutes * 60L
        val configuredSeconds = scenes.sumOf { it.durationSec }.coerceAtLeast(1).toLong()
        // Scene durations are authoritative; the length control remains a useful
        // planning setting and is used as a safety cap for unusually large projects.
        val totalSeconds = configuredSeconds.coerceAtMost(requestedSeconds.coerceAtLeast(1L))
        val cumulative = scenes.runningFold(0L) { acc, scene ->
            acc + scene.durationSec.coerceIn(1, 120)
        }.drop(1)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val startTime = System.currentTimeMillis()
        var elapsedSeconds = 0.0
        var lastReported = -1

        while (elapsedSeconds < totalSeconds) {
            val elapsedWhole = elapsedSeconds.toLong()
            val sceneIndex = cumulative.indexOfFirst { elapsedWhole < it }
                .let { if (it < 0) scenes.lastIndex else it }
                .coerceIn(0, scenes.lastIndex)
            val scene = scenes[sceneIndex]

            val sceneStart = if (sceneIndex == 0) 0L else cumulative[sceneIndex - 1]
            val localSec = (elapsedSeconds - sceneStart).coerceAtLeast(0.0)
            val transitionWindow = 0.8.coerceAtMost(scene.durationSec / 2.0)
            val canvas = surface.lockCanvas()
            try {
                if (sceneIndex > 0 && scene.transition == "Fade" && localSec < transitionWindow) {
                    val previous = scenes[sceneIndex - 1]
                    val progress = (localSec / transitionWindow).toFloat().coerceIn(0f, 1f)
                    drawScene(context, canvas, previous, sceneIndex, scenes.size, paint, 1f - progress, 0f, visualStyle)
                    drawScene(context, canvas, scene, sceneIndex + 1, scenes.size, paint, progress, 0f, visualStyle)
                } else if (sceneIndex > 0 && scene.transition == "Slide" && localSec < transitionWindow) {
                    val previous = scenes[sceneIndex - 1]
                    val progress = (localSec / transitionWindow).toFloat().coerceIn(0f, 1f)
                    drawScene(context, canvas, previous, sceneIndex, scenes.size, paint, 1f, -progress, visualStyle)
                    drawScene(context, canvas, scene, sceneIndex + 1, scenes.size, paint, 1f, 1f - progress, visualStyle)
                } else {
                    drawScene(context, canvas, scene, sceneIndex + 1, scenes.size, paint, 1f, 0f, visualStyle)
                }
            } finally {
                surface.unlockCanvasAndPost(canvas)
            }

            elapsedSeconds = (System.currentTimeMillis() - startTime) / 1000.0
            val percent = ((elapsedSeconds / totalSeconds) * 100).toInt().coerceIn(0, 100)
            if (percent != lastReported) {
                lastReported = percent
                onProgress(percent / 100f, "Rendering scene ${sceneIndex + 1} of ${scenes.size}...")
            }
            Thread.sleep(100L)
        }
        onProgress(1f, "Finalizing video file...")
        recorder.stop()
        recorder.reset()
        output.publish(context)
        output.uri
    } catch (e: Exception) {
        runCatching { recorder.stop() }
        output.cleanup()
        throw e
    } finally {
        runCatching { recorder.release() }
        surface?.release()
    }
}

private data class VideoOutput(
    val uri: Uri,
    val filePath: String,
    val publish: (Context) -> Unit,
    val cleanup: () -> Unit
)

private fun createVideoOutput(context: Context): VideoOutput {
    val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    val name = "TMS_Video_$stamp.mp4"

    if (android.os.Build.VERSION.SDK_INT >= 29) {
        val values = android.content.ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/TMS Video Generator")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val uri = requireNotNull(resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values))
        val temp = File(context.cacheDir, name)
        return VideoOutput(
            uri = uri,
            filePath = temp.absolutePath,
            publish = { ctx ->
                val source = temp
                require(source.exists()) { "Rendered video file was not created" }
                ctx.contentResolver.openOutputStream(uri, "w")!!.use { out ->
                    source.inputStream().use { input -> input.copyTo(out) }
                }
                ctx.contentResolver.update(
                    uri,
                    android.content.ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) },
                    null,
                    null
                )
                source.delete()
            },
            cleanup = {
                runCatching { temp.delete() }
                runCatching { resolver.delete(uri, null, null) }
            }
        )
    }

    val dir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir
    dir.mkdirs()
    val file = File(dir, name)
    val authority = context.packageName + ".fileprovider"
    val uri = FileProvider.getUriForFile(context, authority, file)
    return VideoOutput(
        uri = uri,
        filePath = file.absolutePath,
        publish = { _ -> },
        cleanup = { runCatching { file.delete() } }
    )
}

private fun drawScene(context: Context, canvas: Canvas, scene: Scene, number: Int, total: Int, paint: Paint, alpha: Float = 1f, slideProgress: Float = 0f, visualStyle: String = "Cinematic") {
    val w = canvas.width.toFloat()
    val h = canvas.height.toFloat()
    val checkpoint = canvas.save()
    canvas.translate(canvas.width * slideProgress, 0f)
    paint.alpha = (255f * alpha).toInt().coerceIn(0, 255)
    canvas.drawColor(android.graphics.Color.rgb(18, 20, 28))

    if (visualStyle == "Documentary") {
        paint.alpha = 255
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        canvas.drawRect(3f, 3f, canvas.width - 3f, canvas.height - 3f, paint)
        paint.style = Paint.Style.FILL
    } else if (visualStyle == "Cartoon") {
        paint.alpha = 55
        paint.style = Paint.Style.FILL
        canvas.drawRect(0f, 0f, canvas.width.toFloat(), canvas.height.toFloat(), paint)
        paint.alpha = 255
    }

    val imageHeight = when {
        w > h * 1.2f -> h * 0.45f
        w < h * 0.8f -> h * 0.43f
        else -> h * 0.42f
    }

    scene.imageUri?.let { raw ->
        runCatching {
            context.contentResolver.openInputStream(Uri.parse(raw)).use { input ->
                val bitmap = BitmapFactory.decodeStream(input)
                if (bitmap != null) {
                    val src = android.graphics.Rect(0, 0, bitmap.width, bitmap.height)
                    val dst = android.graphics.Rect(0, 0, canvas.width, imageHeight.toInt())
                    val srcRatio = bitmap.width.toFloat() / bitmap.height.toFloat()
                    val dstRatio = canvas.width.toFloat() / imageHeight.toFloat()
                    val crop = if (srcRatio > dstRatio) {
                        val cropWidth = (bitmap.height * dstRatio).toInt().coerceAtMost(bitmap.width)
                        val left = ((bitmap.width - cropWidth) / 2).coerceAtLeast(0)
                        android.graphics.Rect(left, 0, left + cropWidth, bitmap.height)
                    } else {
                        val cropHeight = (bitmap.width / dstRatio).toInt().coerceAtMost(bitmap.height)
                        val top = ((bitmap.height - cropHeight) / 2).coerceAtLeast(0)
                        android.graphics.Rect(0, top, bitmap.width, top + cropHeight)
                    }
                    canvas.drawBitmap(bitmap, crop, dst, paint)
                    bitmap.recycle()
                }
            }
        }
    }

    val margin = (w * 0.055f).coerceAtLeast(28f)
    val contentWidth = w - margin * 2f
    val textStart = imageHeight + (h * 0.08f).coerceAtLeast(42f)

    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    paint.textSize = (w * 0.038f).coerceIn(28f, 48f)
    paint.setColor(android.graphics.Color.WHITE)
    canvas.drawText("TMS VIDEO GENERATOR", margin, textStart - 28f, paint)

    paint.textSize = (w * 0.027f).coerceIn(22f, 34f)
    canvas.drawText("Scene $number / $total", margin, textStart + 12f, paint)

    paint.textSize = (w * 0.045f).coerceIn(34f, 58f)
    drawWrappedText(
        canvas, scene.title, margin, textStart + 80f, contentWidth, paint,
        if (w < h * 0.8f) 3 else 2
    )

    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
    paint.textSize = (w * 0.024f).coerceIn(22f, 30f)
    val descriptionY = textStart + 80f +
        paint.textSize * 1.35f * if (w < h * 0.8f) 3 else 2
    drawWrappedText(
        canvas, scene.description, margin, descriptionY, contentWidth, paint,
        if (w < h * 0.8f) 8 else 4
    )

    paint.textSize = (w * 0.018f).coerceIn(18f, 22f)
    canvas.drawText("TMS Video Generator • Stage 44", margin, h - margin * 0.55f, paint)
    paint.alpha = 255
    canvas.restoreToCount(checkpoint)
}

private fun drawWrappedText(
    canvas: Canvas,
    text: String,
    x: Float,
    startY: Float,
    maxWidth: Float,
    paint: Paint,
    maxLines: Int
) {
    val words = text.trim().ifBlank { "Untitled" }.split(Regex("\\s+"))
    var line = ""
    var y = startY
    var lines = 0
    for (word in words) {
        val candidate = if (line.isEmpty()) word else "$line $word"
        if (paint.measureText(candidate) > maxWidth && line.isNotEmpty()) {
            canvas.drawText(line, x, y, paint)
            lines++
            if (lines >= maxLines) return
            y += paint.textSize * 1.35f
            line = word
        } else {
            line = candidate
        }
    }
    if (line.isNotEmpty() && lines < maxLines) canvas.drawText(line, x, y, paint)
}

private fun previewVoice(
    context: Context,
    text: String,
    speechRate: Float,
    speechPitch: Float,
    scope: kotlinx.coroutines.CoroutineScope,
    onStarted: (TextToSpeech) -> Unit,
    onComplete: () -> Unit,
    onError: (String) -> Unit
) {
    val tts = TextToSpeech(context) { result ->
        if (result != TextToSpeech.SUCCESS) {
            scope.launch(Dispatchers.Main) { onError("Text-to-speech is not available on this device.") }
            return@TextToSpeech
        }
        tts.language = Locale.getDefault()
        onStarted(tts)
        tts.setSpeechRate(speechRate)
        tts.setPitch(speechPitch)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                scope.launch(Dispatchers.Main) {
                    tts.shutdown()
                    onComplete()
                }
            }
            override fun onError(utteranceId: String?) {
                scope.launch(Dispatchers.Main) {
                    tts.shutdown()
                    onError("Voice preview could not be played.")
                }
            }
        })
        val queued = tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "TMS_VOICE_PREVIEW")
        if (queued == TextToSpeech.ERROR) {
            tts.shutdown()
            scope.launch(Dispatchers.Main) { onError("Voice preview could not be started.") }
        }
    }
}

private fun generateNarration(
    context: Context,
    text: String,
    speechRate: Float,
    speechPitch: Float,
    scope: kotlinx.coroutines.CoroutineScope,
    onStatus: (String) -> Unit,
    onComplete: (Uri) -> Unit,
    onError: (String) -> Unit
) {
    val output = File(context.cacheDir, "TMS_Narration_${System.currentTimeMillis()}.wav")
    val tts = TextToSpeech(context) { result ->
        if (result != TextToSpeech.SUCCESS) {
            scope.launch(Dispatchers.Main) { onError("Text-to-speech is not available on this device.") }
            return@TextToSpeech
        }
        tts.language = Locale.getDefault()
        tts.setSpeechRate(speechRate)
        tts.setPitch(speechPitch)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                scope.launch(Dispatchers.Main) { onStatus("Generating narration audio...") }
            }
            override fun onDone(utteranceId: String?) {
                scope.launch(Dispatchers.Main) {
                    tts.shutdown()
                    if (output.exists() && output.length() > 0) {
                        onComplete(FileProvider.getUriForFile(context, context.packageName + ".fileprovider", output))
                    } else {
                        onError("Narration file was not created.")
                    }
                }
            }
            override fun onError(utteranceId: String?) {
                scope.launch(Dispatchers.Main) {
                    tts.shutdown()
                    runCatching { output.delete() }
                    onError("Narration generation failed.")
                }
            }
        })
        val params = android.os.Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "tms_narration")
        }
        val started = tts.synthesizeToFile(text, params, output, "tms_narration")
        if (started != TextToSpeech.SUCCESS) {
            scope.launch(Dispatchers.Main) {
                tts.shutdown()
                runCatching { output.delete() }
                onError("The phone could not start narration generation.")
            }
        }
    }
}

@OptIn(androidx.media3.common.util.UnstableApi::class)
private fun mixAudioIntoVideo(
    context: Context,
    videoUri: Uri,
    narrationUri: Uri?,
    musicUri: Uri?,
    musicVolume: Float,
    durationMinutes: Int,
    onStatus: (String) -> Unit,
    onComplete: (Uri) -> Unit,
    onError: (String) -> Unit
) {
    require(narrationUri != null || musicUri != null) { "Choose narration or background music first." }
    val outputFile = File(context.cacheDir, "TMS_Video_Audio_${System.currentTimeMillis()}.mp4")
    val videoItem = EditedMediaItem.Builder(MediaItem.fromUri(videoUri)).build()
    val videoSequence = EditedMediaItemSequence.withVideoFrom(listOf(videoItem))
    val sequences = mutableListOf<EditedMediaItemSequence>()
    sequences += videoSequence
    val endMs = durationMinutes * 60_000L

    narrationUri?.let { uri ->
        val narrationMediaItem = MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setEndPositionMs(endMs)
                    .build()
            )
            .build()
        val narrationItem = EditedMediaItem.Builder(narrationMediaItem).build()
        sequences += EditedMediaItemSequence.withAudioFrom(listOf(narrationItem))
    }

    musicUri?.let { uri ->
        val musicMediaItem = MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setEndPositionMs(endMs)
                    .build()
            )
            .build()
        val gain = GainProcessor(
            DefaultGainProvider.Builder(musicVolume.coerceIn(0f, 1f)).build()
        )
        val musicItem = EditedMediaItem.Builder(musicMediaItem)
            .setEffects(Effects(listOf(gain), emptyList()))
            .build()
        sequences += EditedMediaItemSequence.withAudioFrom(listOf(musicItem))
            .buildUpon()
            .setIsLooping(true)
            .build()
    }

    val composition = Composition.Builder(sequences).build()
    val handler = Handler(Looper.getMainLooper())
    val transformer = Transformer.Builder(context)
        .setAudioMimeType(MimeTypes.AUDIO_AAC)
        .addListener(object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                handler.post {
                    runCatching {
                        require(outputFile.exists() && outputFile.length() > 0) { "Final video file was not created." }
                        val uri = publishVideoFile(context, outputFile, "TMS_Video_Final")
                        onComplete(uri)
                    }.onFailure { error ->
                        outputFile.delete()
                        onError("Final video could not be saved: ${error.message ?: "Unknown error"}")
                    }
                }
            }

            override fun onError(
                composition: Composition,
                exportResult: ExportResult,
                exportException: ExportException
            ) {
                handler.post {
                    outputFile.delete()
                    onError("Audio mix failed: ${exportException.message ?: "Media export error"}")
                }
            }
        })
        .build()

    onStatus("Starting final video export...")
    runCatching { transformer.start(composition, outputFile.absolutePath) }
        .onFailure { error ->
            outputFile.delete()
            onError("Could not start final export: ${error.message ?: "Unknown error"}")
        }
}

private fun publishVideoFile(context: Context, source: File, prefix: String = "TMS_Video_Narrated"): Uri {
    val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    val name = "${prefix}_$stamp.mp4"
    if (android.os.Build.VERSION.SDK_INT >= 29) {
        val values = android.content.ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/TMS Video Generator")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val uri = requireNotNull(resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values))
        return try {
            resolver.openOutputStream(uri, "w")!!.use { out -> source.inputStream().use { input -> input.copyTo(out) } }
            resolver.update(uri, android.content.ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
            source.delete()
            uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
    }
    val dir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir
    dir.mkdirs()
    val target = File(dir, name)
    source.copyTo(target, overwrite = true)
    source.delete()
    return FileProvider.getUriForFile(context, context.packageName + ".fileprovider", target)
}

private fun shareAudio(context: Context, uri: Uri) {
    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = "audio/wav"
        putExtra(android.content.Intent.EXTRA_STREAM, uri)
        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(android.content.Intent.createChooser(intent, "Share narration audio"))
}

private fun shareVideo(context: Context, uri: Uri) {
    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = "video/mp4"
        putExtra(android.content.Intent.EXTRA_STREAM, uri)
        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(android.content.Intent.createChooser(intent, "Share TMS video"))
}
