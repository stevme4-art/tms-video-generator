# TMS AI Video Generator — Stage 27

Stage 27 builds on the corrected Stage 25/26 project structure.

## Added
- Add scenes up to 30.
- Delete scenes with automatic renumbering.
- Existing scene editing, preview, image attachment, saving/restoring, local MP4 draft rendering, and sharing remain.

## Important
The local renderer creates a slideshow-style MP4 from scene text and attached images. Automatic AI image/video generation, narration, and music are not included yet.
